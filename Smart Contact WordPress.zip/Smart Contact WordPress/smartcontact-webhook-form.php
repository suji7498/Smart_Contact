<?php
/**
 * Plugin Name: SmartContact Webhook Form
 * Plugin URI: https://www.linkedin.com/in/suraj-jd/
 * Description: SmartContact is a smart contact form for WordPress that stores submissions in JSON and sends data to webhooks (n8n, Zapier, etc.). Includes popup and page form options. Developed by Suraj JD.
 * Version: 1.0.0
 * Author: Suraj JD
 * Author URI: https://www.linkedin.com/in/suraj-jd/
 * License: GPL v2 or later
 * Text Domain: smartcontact
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('SMARTCONTACT_VERSION', '1.0.0');
define('SMARTCONTACT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SMARTCONTACT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SMARTCONTACT_SUBMISSIONS_FILE', SMARTCONTACT_PLUGIN_DIR . 'data/submissions.json');

class SmartContactWebhookForm {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        add_action('admin_init', array($this, 'maybe_redirect_after_activation'));
    }
    
    public function init() {
        // Load text domain
        load_plugin_textdomain('smartcontact', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Admin hooks
        if (is_admin()) {
            add_action('admin_menu', array($this, 'admin_menu'));
            add_action('admin_init', array($this, 'admin_init'));
            add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
        }
        
        // Frontend hooks
        add_action('wp_enqueue_scripts', array($this, 'frontend_scripts'));
        add_shortcode('smartcontact_form', array($this, 'render_form'));
        add_shortcode('smartcontact_form_popup', array($this, 'render_popup_form'));
        add_action('wp_ajax_smartcontact_submit', array($this, 'handle_form_submission'));
        add_action('wp_ajax_nopriv_smartcontact_submit', array($this, 'handle_form_submission'));
        add_action('wp_ajax_smartcontact_test_webhook', array($this, 'test_webhook'));
        add_action('wp_ajax_smartcontact_save_custom_fields', array($this, 'save_custom_fields'));
        add_action('wp_ajax_smartcontact_get_custom_fields', array($this, 'get_custom_fields'));
        add_action('wp_ajax_smartcontact_get_form_preview', array($this, 'get_form_preview'));
        add_action('wp_ajax_smartcontact_clear_all_data', array($this, 'clear_all_data'));
        add_action('wp_ajax_smartcontact_save_popup_settings', array($this, 'save_popup_settings'));
        add_action('wp_footer', array($this, 'popup_form'));
        add_action('wp_footer', array($this, 'session_popup_script'));
    }
    
    public function activate() {
        // Set default options
        $default_options = array(
            'webhook_url' => '',
            'webhook_method' => 'POST',
            'form_title' => 'Get in Touch',
            'form_description' => 'Send us a message and we\'ll respond as soon as possible.',
            'theme' => 'skyblue',
            'captcha_enabled' => true,
            'popup_enabled' => false,
            'popup_delay' => 5000,
            'popup_session_delay' => 86400,
            'session_popup_enabled' => false,
            'session_popup_time' => 300,
            'custom_fields' => array(),
        );
        foreach ($default_options as $key => $value) {
            if (get_option('smartcontact_settings') === false) {
                add_option('smartcontact_settings', $default_options);
            }
        }
        // Set a transient to trigger redirect after activation
        set_transient('smartcontact_activation_redirect', true, 30);
        $this->initialize_json_storage();
    }

    // Redirect to plugin panel after activation
    public function maybe_redirect_after_activation() {
        if (get_transient('smartcontact_activation_redirect')) {
            delete_transient('smartcontact_activation_redirect');
            if (!isset($_GET['activate-multi'])) {
                wp_safe_redirect(admin_url('admin.php?page=smartcontact-settings'));
                exit;
            }
        }
    }
    
    public function deactivate() {
        // Clean up if needed
    }
    
    private function initialize_json_storage() {
        // Create data directory if it doesn't exist
        $data_dir = dirname(SMARTCONTACT_SUBMISSIONS_FILE);
        if (!file_exists($data_dir)) {
            wp_mkdir_p($data_dir);
        }
        
        // Create .htaccess to protect the data directory
        $htaccess_file = $data_dir . '/.htaccess';
        if (!file_exists($htaccess_file)) {
            $htaccess_content = "Order deny,allow\nDeny from all";
            file_put_contents($htaccess_file, $htaccess_content);
        }
        
        // Initialize JSON file if it doesn't exist
        if (!file_exists(SMARTCONTACT_SUBMISSIONS_FILE)) {
            $initial_data = array(
                'submissions' => array(),
                'last_id' => 0,
                'created_at' => current_time('mysql'),
                'total_submissions' => 0
            );
            $this->save_submissions_to_file($initial_data);
        }
    }
    
    private function get_submissions_from_file() {
        if (!file_exists(SMARTCONTACT_SUBMISSIONS_FILE)) {
            $this->initialize_json_storage();
        }
        
        $json_content = file_get_contents(SMARTCONTACT_SUBMISSIONS_FILE);
        $data = json_decode($json_content, true);
        
        if (!$data || !is_array($data)) {
            // If file is corrupted, reinitialize
            $this->initialize_json_storage();
            $json_content = file_get_contents(SMARTCONTACT_SUBMISSIONS_FILE);
            $data = json_decode($json_content, true);
        }
        
        return $data;
    }
    
    private function save_submissions_to_file($data) {
        // Ensure data directory exists
        $data_dir = dirname(SMARTCONTACT_SUBMISSIONS_FILE);
        if (!file_exists($data_dir)) {
            wp_mkdir_p($data_dir);
        }
        
        // Add updated timestamp
        $data['updated_at'] = current_time('mysql');
        
        // Save with pretty formatting for readability
        $json_content = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        
        // Use file_put_contents with LOCK_EX for atomic writes
        $result = file_put_contents(SMARTCONTACT_SUBMISSIONS_FILE, $json_content, LOCK_EX);
        
        if ($result === false) {
            error_log('SmartContact: Failed to save submissions to JSON file');
            return false;
        }
        
        return true;
    }
    
    private function add_submission($submission_data) {
        $data = $this->get_submissions_from_file();
        
        // Generate new ID
        $data['last_id']++;
        $submission_id = $data['last_id'];
        
        // Prepare submission record
        $submission = array(
            'id' => $submission_id,
            'name' => $submission_data['name'],
            'email' => $submission_data['email'],
            'subject' => $submission_data['subject'],
            'message' => $submission_data['message'],
            'custom_fields' => $submission_data['custom_fields'],
            'page_url' => $submission_data['page_url'],
            'page_title' => $submission_data['page_title'],
            'referrer_url' => $submission_data['referrer_url'],
            'webhook_response' => $submission_data['webhook_response'],
            'submission_time' => current_time('mysql'),
            'ip_address' => $submission_data['ip_address'],
            'user_agent' => $submission_data['user_agent']
        );
        
        // Add to submissions array
        $data['submissions'][] = $submission;
        $data['total_submissions']++;
        
        // Save back to file
        return $this->save_submissions_to_file($data) ? $submission_id : false;
    }
    
    private function update_submission($submission_id, $update_data) {
        $data = $this->get_submissions_from_file();
        
        foreach ($data['submissions'] as &$submission) {
            if ($submission['id'] == $submission_id) {
                $submission = array_merge($submission, $update_data);
                return $this->save_submissions_to_file($data);
            }
        }
        
        return false;
    }
    

    
    public function get_submissions($limit = null, $offset = 0) {
        $data = $this->get_submissions_from_file();
        
        // Sort by submission time (newest first)
        usort($data['submissions'], function($a, $b) {
            return strtotime($b['submission_time']) - strtotime($a['submission_time']);
        });
        
        if ($limit !== null) {
            return array_slice($data['submissions'], $offset, $limit);
        }
        
        return $data['submissions'];
    }
    
    public function get_submission_count() {
        $data = $this->get_submissions_from_file();
        return $data['total_submissions'];
    }
    
    public function delete_submission($submission_id) {
        $data = $this->get_submissions_from_file();
        
        foreach ($data['submissions'] as $key => $submission) {
            if ($submission['id'] == $submission_id) {
                unset($data['submissions'][$key]);
                $data['submissions'] = array_values($data['submissions']); // Reindex array
                $data['total_submissions']--;
                return $this->save_submissions_to_file($data);
            }
        }
        
        return false;
    }
    
    public function admin_menu() {
        add_menu_page(
            __('SmartContact Settings', 'smartcontact'),
            __('SmartContact', 'smartcontact'),
            'manage_options',
            'smartcontact-settings',
            array($this, 'admin_page'),
            'dashicons-email-alt',
            30
        );
        
        add_submenu_page(
            'smartcontact-settings',
            __('Form Submissions', 'smartcontact'),
            __('Submissions', 'smartcontact'),
            'manage_options',
            'smartcontact-submissions',
            array($this, 'submissions_page')
        );
    }
    
    public function admin_init() {
        register_setting('smartcontact_settings', 'smartcontact_settings', array($this, 'sanitize_settings'));
        
        // WordPress Settings API registration is disabled since we're using a custom template
        // The settings are now handled directly in the admin-page.php template
        
        /*
        // Webhook Settings Section
        add_settings_section(
            'webhook_settings',
            __('Webhook Configuration', 'smartcontact'),
            array($this, 'webhook_section_callback'),
            'smartcontact-settings'
        );
        
        // Form Settings Section
        add_settings_section(
            'form_settings',
            __('Form Settings', 'smartcontact'),
            array($this, 'form_section_callback'),
            'smartcontact-settings'
        );
        
        // Popup Settings Section
        add_settings_section(
            'popup_settings',
            __('Popup Settings', 'smartcontact'),
            array($this, 'popup_section_callback'),
            'smartcontact-settings'
        );
        
        // Add fields
        $this->add_admin_fields();
        */
    }
    
    /*
    private function add_admin_fields() {
        $fields = array(
            // Webhook fields
            array('webhook_url', 'webhook_settings', __('Webhook URL', 'smartcontact'), 'url_field'),
            array('webhook_method', 'webhook_settings', __('HTTP Method', 'smartcontact'), 'method_field'),

            // Form fields
            array('form_title', 'form_settings', __('Form Title', 'smartcontact'), 'text_field'),
            array('form_description', 'form_settings', __('Form Description', 'smartcontact'), 'textarea_field'),
            array('theme', 'form_settings', __('Theme', 'smartcontact'), 'theme_field'),
            array('captcha_enabled', 'form_settings', __('Enable CAPTCHA', 'smartcontact'), 'checkbox_field'),

            // Popup fields
            array('popup_enabled', 'popup_settings', __('Enable Popup', 'smartcontact'), 'checkbox_field'),
            array('popup_delay', 'popup_settings', __('Popup Delay (ms)', 'smartcontact'), 'number_field'),
            array('popup_session_delay', 'popup_settings', __('Session Delay (seconds)', 'smartcontact'), 'number_field'),
            array('session_popup_enabled', 'popup_settings', __('Enable Session-based Popup', 'smartcontact'), 'checkbox_field'),
            array('session_popup_time', 'popup_settings', __('Session Time (seconds)', 'smartcontact'), 'number_field'),
        );
        
        foreach ($fields as $field) {
            add_settings_field(
                $field[0],
                $field[2],
                array($this, $field[3]),
                'smartcontact-settings',
                $field[1],
                array('field' => $field[0])
            );
        }
    }
    
    public function webhook_section_callback() {
        echo '<p>' . __('Configure where form submissions should be sent (e.g., n8n, Zapier, custom API)', 'smartcontact') . '</p>';
    }
    
    public function form_section_callback() {
        echo '<p>' . __('Customize your contact form appearance and content', 'smartcontact') . '</p>';
    }
    
    public function popup_section_callback() {
        echo '<p>' . __('Configure popup behavior and timing', 'smartcontact') . '</p>';
    }
    
    public function url_field($args) {
        $options = get_option('smartcontact_settings');
        $value = isset($options[$args['field']]) ? $options[$args['field']] : '';
        echo "<input type='url' name='smartcontact_settings[{$args['field']}]' value='{$value}' class='regular-text' placeholder='https://your-webhook-url.com/hook' />";
        echo "<p class='description'>" . __('Enter the URL where form data should be sent (HTTPS recommended)', 'smartcontact') . "</p>";
    }
    
    public function method_field($args) {
        $options = get_option('smartcontact_settings');
        $value = isset($options[$args['field']]) ? $options[$args['field']] : 'POST';
        $methods = array('POST', 'PUT', 'PATCH');
        
        echo "<select name='smartcontact_settings[{$args['field']}]'>";
        foreach ($methods as $method) {
            $selected = ($value === $method) ? 'selected' : '';
            echo "<option value='{$method}' {$selected}>{$method}</option>";
        }
        echo "</select>";
    }
    
    public function text_field($args) {
        $options = get_option('smartcontact_settings');
        $value = isset($options[$args['field']]) ? $options[$args['field']] : '';
        echo "<input type='text' name='smartcontact_settings[{$args['field']}]' value='{$value}' class='regular-text' />";
    }
    
    public function textarea_field($args) {
        $options = get_option('smartcontact_settings');
        $value = isset($options[$args['field']]) ? $options[$args['field']] : '';
        echo "<textarea name='smartcontact_settings[{$args['field']}]' rows='3' cols='50'>{$value}</textarea>";
    }
    
    public function theme_field($args) {
        $options = get_option('smartcontact_settings');
        $value = isset($options[$args['field']]) ? $options[$args['field']] : 'skyblue';
        $themes = array(
            'skyblue' => __('Sky Blue', 'smartcontact'),
            'pink' => __('Pink', 'smartcontact'),
            'orange' => __('Orange', 'smartcontact'),
            'grey' => __('Grey', 'smartcontact'),
            'black' => __('Black', 'smartcontact')
        );
        
        echo "<select name='smartcontact_settings[{$args['field']}]'>";
        foreach ($themes as $theme_value => $theme_label) {
            $selected = ($value === $theme_value) ? 'selected' : '';
            echo "<option value='{$theme_value}' {$selected}>{$theme_label}</option>";
        }
        echo "</select>";
    }
    
    public function checkbox_field($args) {
        $options = get_option('smartcontact_settings');
        $value = isset($options[$args['field']]) ? $options[$args['field']] : false;
        $checked = $value ? 'checked' : '';
        echo "<input type='checkbox' name='smartcontact_settings[{$args['field']}]' value='1' {$checked} />";
    }
    
    public function number_field($args) {
        $options = get_option('smartcontact_settings');
        $value = isset($options[$args['field']]) ? $options[$args['field']] : '';
        echo "<input type='number' name='smartcontact_settings[{$args['field']}]' value='{$value}' class='small-text' />";
    }
    */
    
    public function sanitize_settings($input) {
        $sanitized = array();
        $existing = get_option('smartcontact_settings');
        
        if (isset($input['webhook_url'])) {
            $sanitized['webhook_url'] = esc_url_raw($input['webhook_url']);
        }
        
        if (isset($input['webhook_method'])) {
            $sanitized['webhook_method'] = sanitize_text_field($input['webhook_method']);
        }
        
        if (isset($input['form_title'])) {
            $sanitized['form_title'] = sanitize_text_field($input['form_title']);
        }
        
        if (isset($input['form_description'])) {
            $sanitized['form_description'] = sanitize_textarea_field($input['form_description']);
        }
        
        if (isset($input['theme'])) {
            $sanitized['theme'] = sanitize_text_field($input['theme']);
        }
        
        $sanitized['captcha_enabled'] = isset($input['captcha_enabled']) ? true : false;
        $sanitized['popup_enabled'] = isset($input['popup_enabled']) ? true : false;
        $sanitized['session_popup_enabled'] = isset($input['session_popup_enabled']) ? true : false;

        if (isset($input['popup_delay'])) {
            $sanitized['popup_delay'] = absint($input['popup_delay']);
        }

        if (isset($input['popup_session_delay'])) {
            $sanitized['popup_session_delay'] = absint($input['popup_session_delay']);
        }

        if (isset($input['session_popup_time'])) {
            $sanitized['session_popup_time'] = absint($input['session_popup_time']);
        }

        // Handle custom fields: preserve if not present in input
        if (isset($input['custom_fields'])) {
            $sanitized['custom_fields'] = array();
            foreach ($input['custom_fields'] as $field) {
                if (!empty($field['label'])) {
                    $sanitized['custom_fields'][] = array(
                        'label' => sanitize_text_field($field['label']),
                        'type' => sanitize_text_field($field['type']),
                        'required' => (!empty($field['required']) && ($field['required'] === '1' || $field['required'] === 1 || $field['required'] === true || $field['required'] === 'on')),
                        'placeholder' => sanitize_text_field($field['placeholder'])
                    );
                }
            }
        } else if (!empty($existing['custom_fields'])) {
            $sanitized['custom_fields'] = $existing['custom_fields'];
        }

        return $sanitized;
    }
    
    public function admin_scripts($hook) {
        if ($hook === 'toplevel_page_smartcontact-settings') {
            wp_enqueue_script('smartcontact-admin', SMARTCONTACT_PLUGIN_URL . 'assets/admin.js', array('jquery'), SMARTCONTACT_VERSION, true);
            wp_enqueue_style('smartcontact-admin', SMARTCONTACT_PLUGIN_URL . 'assets/admin.css', array(), SMARTCONTACT_VERSION);
            
            wp_localize_script('smartcontact-admin', 'smartcontact_admin', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('smartcontact_admin'),
                'test_webhook_text' => __('Testing...', 'smartcontact')
            ));
        }
    }
    
    public function frontend_scripts() {
        wp_enqueue_style('smartcontact-frontend', SMARTCONTACT_PLUGIN_URL . 'assets/frontend.css', array(), SMARTCONTACT_VERSION);
        wp_enqueue_script('smartcontact-frontend', SMARTCONTACT_PLUGIN_URL . 'assets/frontend.js', array('jquery'), SMARTCONTACT_VERSION, true);
        
        $options = get_option('smartcontact_settings');
        
        wp_localize_script('smartcontact-frontend', 'smartcontact', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('smartcontact_frontend'),
            'popup_enabled' => $options['popup_enabled'] ?? false,
            'popup_delay' => $options['popup_delay'] ?? 5000,
            'popup_session_delay' => $options['popup_session_delay'] ?? 86400,
            'session_popup_enabled' => $options['session_popup_enabled'] ?? false,
            'session_popup_time' => $options['session_popup_time'] ?? 300,
            'strings' => array(
                'sending' => __('Sending...', 'smartcontact'),
                'success' => __('Message sent successfully!', 'smartcontact'),
                'error' => __('Error sending message. Please try again.', 'smartcontact'),
                'required_fields' => __('Please fill in all required fields.', 'smartcontact'),
                'invalid_email' => __('Please enter a valid email address.', 'smartcontact'),
                'captcha_error' => __('Incorrect captcha answer.', 'smartcontact')
            )
        ));
    }
    
    public function render_form($atts = array()) {
        $atts = shortcode_atts(array(
            'title' => '',
            'description' => '',
            'theme' => '',
            'show_title' => 'true'
        ), $atts);
        
        $options = get_option('smartcontact_settings');
        
        $title = !empty($atts['title']) ? $atts['title'] : ($options['form_title'] ?? 'Get in Touch');
        $description = !empty($atts['description']) ? $atts['description'] : ($options['form_description'] ?? 'Send us a message and we\'ll respond as soon as possible.');
        $theme = !empty($atts['theme']) ? $atts['theme'] : ($options['theme'] ?? 'skyblue');
        $captcha_enabled = $options['captcha_enabled'] ?? true;
        $custom_fields = $options['custom_fields'] ?? array();
        
        // Generate CAPTCHA
        $num1 = rand(1, 10);
        $num2 = rand(1, 10);
        $captcha_question = "{$num1} + {$num2} = ?";
        $captcha_answer = $num1 + $num2;
        
        ob_start();
        include SMARTCONTACT_PLUGIN_DIR . 'templates/form.php';
        return ob_get_clean();
    }
    
    public function render_popup_form($atts = array()) {
        // Use the same attributes as render_form, but add a flag for popup mode
        $atts = shortcode_atts(array(
            'title' => '',
            'description' => '',
            'theme' => '',
            'popup' => true, // force popup mode
            'show_title' => 'true'
        ), $atts);
        $atts['popup'] = true;
        // Only output the popup overlay, not the inline form
        ob_start();
        include SMARTCONTACT_PLUGIN_DIR . 'templates/form.php';
        return ob_get_clean();
    }
    
    public function popup_form() {
        $options = get_option('smartcontact_settings');
        
        if (!($options['popup_enabled'] ?? false)) {
            return;
        }
        
        // Check if popup should be shown based on session
        if (isset($_COOKIE['smartcontact_popup_shown'])) {
            return;
        }
        
        echo '<div id="smartcontact-popup-overlay" class="smartcontact-popup-overlay" style="display: none;">';
        echo '<div class="smartcontact-popup-container">';
        echo '<div class="smartcontact-popup-content">';
        
        // Get the form content
        $form_content = $this->render_form(array('show_title' => 'true'));
        
        // Add close button before the closing form tag
        $form_content = str_replace(
            '</form>',
            '<button type="button" class="smartcontact-popup-close">Close</button></form>',
            $form_content
        );
        
        echo $form_content;
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
    
    public function handle_form_submission() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['smartcontact_nonce'], 'smartcontact_frontend')) {
            wp_die(__('Security check failed.', 'smartcontact'));
        }
        
        // Sanitize input
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $subject = sanitize_text_field($_POST['subject']);
        $message = sanitize_textarea_field($_POST['message']);
        $captcha = intval($_POST['captcha']);
        $captcha_answer = intval($_POST['captcha_answer']);

        // Capture page tracking data
        $page_url = isset($_POST['page_url']) ? esc_url_raw($_POST['page_url']) : '';
        $page_title = isset($_POST['page_title']) ? sanitize_text_field($_POST['page_title']) : '';
        $referrer_url = isset($_POST['referrer_url']) ? esc_url_raw($_POST['referrer_url']) : '';

        // Build full page URL if it's relative
        if ($page_url && !parse_url($page_url, PHP_URL_HOST)) {
            $page_url = home_url($page_url);
        }

        // Handle custom fields
        $custom_field_data = array();
        $options = get_option('smartcontact_settings');
        if (!empty($options['custom_fields'])) {
            foreach ($options['custom_fields'] as $field) {
                // Generate the same field name as in the form template
                $field_name = 'custom_' . sanitize_key($field['label']);
                
                // Check if the field was submitted
                if (isset($_POST[$field_name]) && !empty($_POST[$field_name])) {
                    $custom_field_data[$field['label']] = sanitize_text_field($_POST[$field_name]);
                }
            }
        }
        

        
        // Validate required fields
        if (empty($name) || empty($email) || empty($message)) {
            wp_send_json_error(__('Please fill in all required fields.', 'smartcontact'));
        }
        
        // Validate email
        if (!is_email($email)) {
            wp_send_json_error(__('Please enter a valid email address.', 'smartcontact'));
        }
        
        // Validate CAPTCHA
        $options = get_option('smartcontact_settings');
        if ($options['captcha_enabled'] && $captcha !== $captcha_answer) {
            wp_send_json_error(__('Incorrect captcha answer.', 'smartcontact'));
        }
        
        // Prepare submission data
        $submission_data = array(
            'name' => $name,
            'email' => $email,
            'subject' => $subject,
            'message' => $message,
            'custom_fields' => $custom_field_data,
            'page_url' => $page_url,
            'page_title' => $page_title,
            'referrer_url' => $referrer_url,
            'ip_address' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'webhook_response' => null
        );
        
        // Send to webhook if configured
        if (!empty($options['webhook_url'])) {
            $webhook_response = $this->send_to_webhook($options, array(
                'name' => $name,
                'email' => $email,
                'subject' => $subject,
                'message' => $message,
                'custom_fields' => $custom_field_data,
                'page_url' => $page_url,
                'page_title' => $page_title,
                'referrer_url' => $referrer_url,
                'timestamp' => current_time('mysql'),
                'source' => 'WordPress Contact Form'
            ));
            
            $submission_data['webhook_response'] = $webhook_response;
        }
        
        // Store submission in JSON file
        $submission_id = $this->add_submission($submission_data);
        
        if ($submission_id === false) {
            wp_send_json_error(__('Failed to save submission. Please try again.', 'smartcontact'));
        }
        
        wp_send_json_success(__('Message sent successfully!', 'smartcontact'));
    }
    
    private function send_to_webhook($options, $data) {
        $response = wp_remote_request($options['webhook_url'], array(
            'method' => $options['webhook_method'],
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($data),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array('error' => $response->get_error_message());
        }
        
        return array(
            'status_code' => wp_remote_retrieve_response_code($response),
            'body' => wp_remote_retrieve_body($response)
        );
    }
    
    public function get_form_preview() {
        // Verify nonce and permissions
        if (!wp_verify_nonce($_POST['nonce'], 'smartcontact_admin') || !current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'smartcontact'));
        }
        
        $options = get_option('smartcontact_settings');
        
        // Get current form settings
        $title = $options['form_title'] ?? 'Get in Touch';
        $description = $options['form_description'] ?? 'Send us a message and we\'ll respond as soon as possible.';
        $theme = $options['theme'] ?? 'skyblue';
        $captcha_enabled = $options['captcha_enabled'] ?? true;
        $custom_fields = $options['custom_fields'] ?? array();
        
        // Generate CAPTCHA
        $num1 = rand(1, 10);
        $num2 = rand(1, 10);
        $captcha_question = "{$num1} + {$num2} = ?";
        $captcha_answer = $num1 + $num2;
        
        ob_start();
        include SMARTCONTACT_PLUGIN_DIR . 'templates/form.php';
        $html = ob_get_clean();
        
        // Add some debugging
        error_log('SmartContact Preview: Generated HTML length: ' . strlen($html));
        
        wp_send_json_success(array('html' => $html));
    }
    
    public function test_webhook() {
        // Verify nonce and permissions
        if (!wp_verify_nonce($_POST['nonce'], 'smartcontact_admin') || !current_user_can('manage_options')) {
            wp_die(__('Permission denied.', 'smartcontact'));
        }
        
        $options = get_option('smartcontact_settings');
        
        if (empty($options['webhook_url'])) {
            wp_send_json_error(__('Please enter a webhook URL first.', 'smartcontact'));
        }
        
        $test_data = array(
            'test' => true,
            'name' => 'Test User',
            'email' => 'test@example.com',
            'subject' => 'Test Message',
            'message' => 'This is a test message from SmartContact admin panel.',
            'custom_fields' => array(
                'Mobile Number' => '+1-555-123-4567',
                'Company' => 'Test Company Inc.'
            ),
            'page_url' => home_url('/admin-test-page/'),
            'page_title' => 'Admin Test Page',
            'referrer_url' => admin_url('admin.php?page=smartcontact-settings'),
            'timestamp' => current_time('mysql'),
            'source' => 'Admin Test'
        );
        
        $response = $this->send_to_webhook($options, $test_data);
        
        if (isset($response['error'])) {
            wp_send_json_error($response['error']);
        }
        
        wp_send_json_success(sprintf(__('Test successful! HTTP %d', 'smartcontact'), $response['status_code']));
    }
    
    public function admin_page() {
        include SMARTCONTACT_PLUGIN_DIR . 'templates/admin-page.php';
    }
    
    public function submissions_page() {
        include SMARTCONTACT_PLUGIN_DIR . 'templates/submissions-page.php';
    }

    public function save_custom_fields() {
        // Verify nonce and permissions
        if (!wp_verify_nonce($_POST['nonce'], 'smartcontact_admin') || !current_user_can('manage_options')) {
            wp_die(__('Permission denied.', 'smartcontact'));
        }

        $options = get_option('smartcontact_settings');
        $custom_fields = array();

        if (isset($_POST['custom_fields'])) {
            foreach ($_POST['custom_fields'] as $field) {
                if (!empty($field['label'])) {
                    $type = sanitize_text_field($field['type']);
                    if ($type !== 'text') $type = 'text';
                    $custom_fields[] = array(
                        'label' => sanitize_text_field($field['label']),
                        'type' => $type,
                        'required' => (!empty($field['required']) && ($field['required'] === '1' || $field['required'] === 1 || $field['required'] === true || $field['required'] === 'on')),
                        'placeholder' => sanitize_text_field($field['placeholder'])
                    );
                }
            }
        }

        $options['custom_fields'] = $custom_fields;
        update_option('smartcontact_settings', $options);

        wp_send_json_success(__('Custom fields saved successfully!', 'smartcontact'));
    }

    public function session_popup_script() {
        $options = get_option('smartcontact_settings');

        if (!($options['session_popup_enabled'] ?? false)) {
            return;
        }

        $session_time = $options['session_popup_time'] ?? 300; // Default 5 minutes
        ?>
        <script>
        jQuery(document).ready(function($) {
            // Session-based popup functionality
            var sessionStartTime = sessionStorage.getItem('smartcontact_session_start');
            var popupShown = sessionStorage.getItem('smartcontact_session_popup_shown');

            if (!sessionStartTime) {
                sessionStartTime = Date.now();
                sessionStorage.setItem('smartcontact_session_start', sessionStartTime);
            }

            if (!popupShown) {
                setTimeout(function() {
                    var currentTime = Date.now();
                    var sessionDuration = (currentTime - parseInt(sessionStartTime)) / 1000;

                    if (sessionDuration >= <?php echo $session_time; ?>) {
                        // Show session popup
                        showSessionPopup();
                        sessionStorage.setItem('smartcontact_session_popup_shown', 'true');
                    }
                }, <?php echo $session_time * 1000; ?>);
            }

            function showSessionPopup() {
                var popupHtml = '<div id="smartcontact-session-popup" style="position: fixed; top: 20px; right: 20px; background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); z-index: 99999; max-width: 300px;">' +
                    '<button onclick="closeSessionPopup()" style="position: absolute; top: 5px; right: 10px; background: none; border: none; font-size: 18px; cursor: pointer;">&times;</button>' +
                    '<h4 style="margin: 0 0 10px 0;">Need Help?</h4>' +
                    '<p style="margin: 0 0 15px 0; font-size: 14px;">You\'ve been browsing for a while. Do you have any questions we can help with?</p>' +
                    '<button onclick="showContactForm()" style="background: #0073aa; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Contact Us</button>' +
                    '</div>';

                $('body').append(popupHtml);

                // Auto-hide after 10 seconds
                setTimeout(function() {
                    closeSessionPopup();
                }, 10000);
            }

            window.closeSessionPopup = function() {
                $('#smartcontact-session-popup').remove();
            };

            window.showContactForm = function() {
                closeSessionPopup();
                $('#smartcontact-popup-overlay').fadeIn(300);
            };
        });
        </script>
        <?php
    }
    
    public function clear_all_data() {
        // Verify nonce and permissions
        if (!wp_verify_nonce($_POST['nonce'], 'smartcontact_admin') || !current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'smartcontact'));
        }
        
        // Delete the submissions file
        if (file_exists(SMARTCONTACT_SUBMISSIONS_FILE)) {
            if (unlink(SMARTCONTACT_SUBMISSIONS_FILE)) {
                // Reinitialize empty storage
                $this->initialize_json_storage();
                wp_send_json_success(__('All submission data has been deleted successfully.', 'smartcontact'));
            } else {
                wp_send_json_error(__('Failed to delete submission data file.', 'smartcontact'));
            }
        } else {
            wp_send_json_success(__('No submission data found to delete.', 'smartcontact'));
        }
    }
    
    public function save_popup_settings() {
        // Verify nonce and permissions
        if (!wp_verify_nonce($_POST['nonce'], 'smartcontact_admin') || !current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'smartcontact'));
        }

        $popup_settings = $_POST['popup_settings'] ?? array();
        $options = get_option('smartcontact_settings');

        // Update only popup-related settings
        $options['popup_enabled'] = isset($popup_settings['popup_enabled']) ? (bool)$popup_settings['popup_enabled'] : false;
        $options['popup_delay'] = isset($popup_settings['popup_delay']) ? absint($popup_settings['popup_delay']) : 5000;
        $options['popup_session_delay'] = isset($popup_settings['popup_session_delay']) ? absint($popup_settings['popup_session_delay']) : 86400;
        $options['session_popup_enabled'] = isset($popup_settings['session_popup_enabled']) ? (bool)$popup_settings['session_popup_enabled'] : false;
        $options['session_popup_time'] = isset($popup_settings['session_popup_time']) ? absint($popup_settings['session_popup_time']) : 300;

        update_option('smartcontact_settings', $options);

        wp_send_json_success(__('Popup settings saved successfully!', 'smartcontact'));
    }
}

// Initialize the plugin
new SmartContactWebhookForm();
