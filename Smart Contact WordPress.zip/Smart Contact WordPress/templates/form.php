<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<?php if (!empty($atts['popup'])): ?>
    <div id="smartcontact-popup-overlay" class="smartcontact-popup-overlay" style="display: none;">
        <div class="smartcontact-popup-container" style="width:50vw; height:100vh; max-width:600px; min-width:320px; max-height:100vh; border-radius:16px; margin:auto;">
            <button class="smartcontact-popup-close" aria-label="Close" style="position:absolute;top:10px;right:10px;z-index:2;">&times;</button>
            <div class="smartcontact-popup-content" style="overflow-y: auto; max-height: 100%; padding-top: 40px;">
                <div class="smartcontact-form-container smartcontact-theme-<?php echo esc_attr($theme); ?>">
                    <form id="smartcontact-form" class="smartcontact-form" method="post">
                        <?php wp_nonce_field('smartcontact_frontend', 'smartcontact_nonce'); ?>
                        <input type="hidden" name="page_url" value="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>">
                        <input type="hidden" name="page_title" value="<?php echo esc_attr(get_the_title()); ?>">
                        <input type="hidden" name="referrer_url" value="<?php echo esc_url(wp_get_referer()); ?>">
                        <div class="smartcontact-form-group">
                            <label for="smartcontact-name" class="smartcontact-label">
                                <?php _e('Name', 'smartcontact'); ?> <span class="smartcontact-required">*</span>
                            </label>
                            <input type="text" id="smartcontact-name" name="name" class="smartcontact-input" placeholder="<?php _e('Your full name', 'smartcontact'); ?>" required>
                        </div>
                        <div class="smartcontact-form-group">
                            <label for="smartcontact-email" class="smartcontact-label">
                                <?php _e('Email', 'smartcontact'); ?> <span class="smartcontact-required">*</span>
                            </label>
                            <input type="email" id="smartcontact-email" name="email" class="smartcontact-input" placeholder="<?php _e('your.email@example.com', 'smartcontact'); ?>" required>
                        </div>
                        <div class="smartcontact-form-group">
                            <label for="smartcontact-subject" class="smartcontact-label">
                                <?php _e('Subject', 'smartcontact'); ?>
                            </label>
                            <input type="text" id="smartcontact-subject" name="subject" class="smartcontact-input" placeholder="<?php _e('What is this regarding?', 'smartcontact'); ?>">
                        </div>
                        <div class="smartcontact-form-group">
                            <label for="smartcontact-message" class="smartcontact-label">
                                <?php _e('Message', 'smartcontact'); ?> <span class="smartcontact-required">*</span>
                            </label>
                            <textarea id="smartcontact-message" name="message" class="smartcontact-textarea" rows="4" placeholder="<?php _e('Type your message...', 'smartcontact'); ?>" required></textarea>
                        </div>
                        <?php if ($captcha_enabled): ?>
                            <div class="smartcontact-form-group smartcontact-captcha-group">
                                <label for="smartcontact-captcha" class="smartcontact-label">
                                    <?php _e('Security Check', 'smartcontact'); ?> <span class="smartcontact-required">*</span>
                                </label>
                                <div class="smartcontact-captcha-container">
                                    <span class="smartcontact-captcha-question"><?php echo esc_html($captcha_question); ?></span>
                                    <input type="number" id="smartcontact-captcha" name="captcha" class="smartcontact-input smartcontact-captcha-input" placeholder="<?php _e('Answer', 'smartcontact'); ?>" required>
                                    <input type="hidden" name="captcha_answer" value="<?php echo esc_attr($captcha_answer); ?>">
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="smartcontact-form-group">
                            <button type="submit" class="smartcontact-submit-btn">
                                <span class="smartcontact-btn-text"><?php _e('Send', 'smartcontact'); ?></span>
                                <span class="smartcontact-btn-loading" style="display: none;"><?php _e('Sending...', 'smartcontact'); ?></span>
                            </button>
                        </div>
                        <div id="smartcontact-message-container" class="smartcontact-message-container" style="display: none;">
                            <div id="smartcontact-message" class="smartcontact-message"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
<div class="smartcontact-form-container smartcontact-theme-<?php echo esc_attr($theme); ?>">
    <?php if ($atts['show_title'] === 'true'): ?>
        <div class="smartcontact-header">
            <h2 class="smartcontact-title"><?php echo esc_html($title); ?></h2>
            <p class="smartcontact-description"><?php echo esc_html($description); ?></p>
        </div>
    <?php endif; ?>
    
    <!-- Form Progress Indicator -->
    <div class="smartcontact-progress-indicator" style="display: none;">
        <div class="smartcontact-progress-bar">
            <div class="smartcontact-progress-fill"></div>
        </div>
        <p class="smartcontact-progress-text"><?php _e('Sending your message...', 'smartcontact'); ?></p>
    </div>
    
    <form id="smartcontact-form" class="smartcontact-form" method="post">
        <?php wp_nonce_field('smartcontact_frontend', 'smartcontact_nonce'); ?>
        <input type="hidden" name="page_url" value="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>">
        <input type="hidden" name="page_title" value="<?php echo esc_attr(get_the_title()); ?>">
        <input type="hidden" name="referrer_url" value="<?php echo esc_url(wp_get_referer()); ?>">
        
        <div class="smartcontact-form-group smartcontact-form-row">
            <div class="smartcontact-form-field">
                <label for="smartcontact-name" class="smartcontact-label">
                    <?php _e('Name', 'smartcontact'); ?> <span class="smartcontact-required">*</span>
                </label>
                <input type="text" id="smartcontact-name" name="name" class="smartcontact-input" placeholder="<?php _e('Your full name', 'smartcontact'); ?>" required>
            </div>
            
            <div class="smartcontact-form-field">
                <label for="smartcontact-email" class="smartcontact-label">
                    <?php _e('Email', 'smartcontact'); ?> <span class="smartcontact-required">*</span>
                </label>
                <input type="email" id="smartcontact-email" name="email" class="smartcontact-input" placeholder="<?php _e('your.email@example.com', 'smartcontact'); ?>" required>
            </div>
        </div>
        
        <div class="smartcontact-form-group">
            <label for="smartcontact-subject" class="smartcontact-label">
                <?php _e('Subject', 'smartcontact'); ?>
            </label>
            <input type="text" id="smartcontact-subject" name="subject" class="smartcontact-input" placeholder="<?php _e('What is this regarding?', 'smartcontact'); ?>">
        </div>
        
        <div class="smartcontact-form-group">
            <label for="smartcontact-message" class="smartcontact-label">
                <?php _e('Message', 'smartcontact'); ?> <span class="smartcontact-required">*</span>
            </label>
            <textarea id="smartcontact-message" name="message" class="smartcontact-textarea" rows="5" placeholder="<?php _e('Tell us more about your inquiry...', 'smartcontact'); ?>" required></textarea>
        </div>

        <?php if (!empty($custom_fields)): ?>
            <?php foreach ($custom_fields as $field): ?>
                <div class="smartcontact-form-group">
                    <label for="smartcontact-custom-<?php echo esc_attr(sanitize_key($field['label'])); ?>" class="smartcontact-label">
                        <?php echo esc_html($field['label']); ?>
                        <?php if ($field['required']): ?>
                            <span class="smartcontact-required">*</span>
                        <?php endif; ?>
                    </label>

                    <?php if ($field['type'] === 'textarea'): ?>
                        <textarea
                            id="smartcontact-custom-<?php echo esc_attr(sanitize_key($field['label'])); ?>"
                            name="custom_<?php echo esc_attr(sanitize_key($field['label'])); ?>"
                            class="smartcontact-textarea"
                            rows="3"
                            placeholder="<?php echo esc_attr($field['placeholder']); ?>"
                            <?php echo $field['required'] ? 'required' : ''; ?>
                        ></textarea>
                    <?php elseif ($field['type'] === 'email'): ?>
                        <input
                            type="email"
                            id="smartcontact-custom-<?php echo esc_attr(sanitize_key($field['label'])); ?>"
                            name="custom_<?php echo esc_attr(sanitize_key($field['label'])); ?>"
                            class="smartcontact-input"
                            placeholder="<?php echo esc_attr($field['placeholder']); ?>"
                            <?php echo $field['required'] ? 'required' : ''; ?>
                        >
                    <?php elseif ($field['type'] === 'tel'): ?>
                        <input
                            type="tel"
                            id="smartcontact-custom-<?php echo esc_attr(sanitize_key($field['label'])); ?>"
                            name="custom_<?php echo esc_attr(sanitize_key($field['label'])); ?>"
                            class="smartcontact-input"
                            placeholder="<?php echo esc_attr($field['placeholder']); ?>"
                            <?php echo $field['required'] ? 'required' : ''; ?>
                        >
                    <?php else: // text field ?>
                        <input
                            type="text"
                            id="smartcontact-custom-<?php echo esc_attr(sanitize_key($field['label'])); ?>"
                            name="custom_<?php echo esc_attr(sanitize_key($field['label'])); ?>"
                            class="smartcontact-input"
                            placeholder="<?php echo esc_attr($field['placeholder']); ?>"
                            <?php echo $field['required'] ? 'required' : ''; ?>
                        >
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <?php if ($captcha_enabled): ?>
            <div class="smartcontact-form-group smartcontact-captcha-group">
                <label for="smartcontact-captcha" class="smartcontact-label">
                    <?php _e('Security Check', 'smartcontact'); ?> <span class="smartcontact-required">*</span>
                </label>
                <div class="smartcontact-captcha-container">
                    <span class="smartcontact-captcha-question"><?php echo esc_html($captcha_question); ?></span>
                    <input type="number" id="smartcontact-captcha" name="captcha" class="smartcontact-input smartcontact-captcha-input" placeholder="<?php _e('Answer', 'smartcontact'); ?>" required>
                    <input type="hidden" name="captcha_answer" value="<?php echo esc_attr($captcha_answer); ?>">
                </div>
            </div>
        <?php endif; ?>
        
        <div class="smartcontact-form-group">
            <button type="submit" class="smartcontact-submit-btn">
                <span class="smartcontact-btn-text"><?php _e('Send Message', 'smartcontact'); ?></span>
                <span class="smartcontact-btn-loading" style="display: none;"><?php _e('Sending...', 'smartcontact'); ?></span>
            </button>
        </div>
        
        <div id="smartcontact-message-container" class="smartcontact-message-container" style="display: none;">
            <div id="smartcontact-message" class="smartcontact-message"></div>
        </div>
    </form>
</div>
<?php endif; ?>
