<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$options = get_option('smartcontact_settings');

// Show admin notices
if (isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true') {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-success is-dismissible"><p><strong>' . __('Settings saved successfully!', 'smartcontact') . '</strong></p></div>';
    });
}
?>

<div class="wrap">
    <h1><?php _e('SmartContact Settings', 'smartcontact'); ?></h1>
    
    <div id="smartcontact-admin-container" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
        <div class="smartcontact-admin-tabs" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
            <nav class="nav-tab-wrapper" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                <a href="#webhook" class="nav-tab nav-tab-active" data-tab="webhook"><?php _e('Webhook Settings', 'smartcontact'); ?></a>
                <a href="#form" class="nav-tab" data-tab="form"><?php _e('Form Settings', 'smartcontact'); ?></a>
                <a href="#popup" class="nav-tab" data-tab="popup"><?php _e('Popup Settings', 'smartcontact'); ?></a>

            </nav>
        </div>
        
        <div class="smartcontact-main-content" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
            <form method="post" action="options.php" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                <?php settings_fields('smartcontact_settings'); ?>
                <?php wp_nonce_field('smartcontact_settings', 'smartcontact_nonce'); ?>
                
                <!-- Universal Save Settings Button -->
                <div class="smartcontact-save-buttons" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important; padding: 15px 30px; background: #f9f9f9; border-bottom: 1px solid #ccd0d4; margin: -30px -30px 20px -30px;">
                    <!-- Universal Save Button -->
                    <div id="universal-save-section" class="save-section">
                        <?php submit_button(__('Save Settings', 'smartcontact'), 'primary', 'submit', false, array('id' => 'submit-universal')); ?>
                    </div>
                    
                    <!-- Preview and Import/Export don't need save buttons -->
                    <div id="preview-save-section" class="save-section" style="display: none;"></div>

                </div>
                
                <!-- Webhook Settings Tab -->
                <div id="tab-webhook" class="smartcontact-tab-content smartcontact-webhook-only" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                    <div class="smartcontact-admin-section" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                        <h2><?php _e('Webhook Configuration', 'smartcontact'); ?></h2>
                        <p class="description"><?php _e('Configure where form submissions should be sent (e.g., n8n, Zapier, custom API)', 'smartcontact'); ?></p>
                        
                        <table class="form-table" style="width: 100% !important; display: table !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                            <tr>
                                <th scope="row">
                                    <label for="webhook_url"><?php _e('Webhook URL', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <input type="url" id="webhook_url" name="smartcontact_settings[webhook_url]" value="<?php echo esc_attr($options['webhook_url'] ?? ''); ?>" class="regular-text" placeholder="https://your-webhook-url.com/hook" style="flex: 1;" />
                                        <a href="https://www.linkedin.com/in/suraj-jd/" target="_blank" class="button button-secondary" style="white-space: nowrap; text-decoration: none;">
                                            <span class="dashicons dashicons-external" style="margin-right: 5px;"></span>
                                            <?php _e('Get Help', 'smartcontact'); ?>
                                        </a>
                                    </div>
                                    <p class="description"><?php _e('Enter the URL where form data should be sent (HTTPS recommended)', 'smartcontact'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="webhook_method"><?php _e('HTTP Method', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <select id="webhook_method" name="smartcontact_settings[webhook_method]">
                                        <option value="POST" <?php selected($options['webhook_method'] ?? 'POST', 'POST'); ?>><?php _e('POST', 'smartcontact'); ?></option>
                                        <option value="PUT" <?php selected($options['webhook_method'] ?? 'POST', 'PUT'); ?>><?php _e('PUT', 'smartcontact'); ?></option>
                                        <option value="PATCH" <?php selected($options['webhook_method'] ?? 'POST', 'PATCH'); ?>><?php _e('PATCH', 'smartcontact'); ?></option>
                                    </select>
                                </td>
                            </tr>
                        </table>
                        
                        <div class="smartcontact-test-webhook" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                            <button type="button" id="test-webhook-btn" class="button button-secondary">
                                <?php _e('Test Webhook', 'smartcontact'); ?>
                            </button>
                            <div id="webhook-test-result" class="smartcontact-test-result"></div>
                        </div>
                    </div>

                    <!-- Shortcode Section -->
                    <div class="smartcontact-admin-section" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                        <h2><?php _e('Shortcode Usage', 'smartcontact'); ?></h2>
                        <p class="description"><?php _e('Use this shortcode to display the contact form on any page or post:', 'smartcontact'); ?></p>
                        
                        <div class="shortcode-display">
                            <div class="shortcode-box">
                                <code id="shortcode-webhook">[smartcontact_form]</code>
                                <button type="button" class="copy-shortcode-btn" data-target="shortcode-webhook">
                                    <span class="copy-text"><?php _e('Copy', 'smartcontact'); ?></span>
                                    <span class="copied-text" style="display: none;"><?php _e('Copied!', 'smartcontact'); ?></span>
                                </button>
                            </div>
                            <p class="shortcode-description"><?php _e('This shortcode will display the contact form with your current webhook settings.', 'smartcontact'); ?></p>
                        </div>
                    </div>
                    

                </div>
                
                <!-- Form Settings Tab (Merged with Custom Fields and Popup Settings) -->
                <div id="tab-form" class="smartcontact-tab-content" style="display: none; width: 100% !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                    
                    <!-- Form Content & Appearance Section -->
                    <div class="smartcontact-admin-section" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                        <h2><?php _e('Form Content & Appearance', 'smartcontact'); ?></h2>
                        <p class="description"><?php _e('Customize your contact form title, description, and appearance', 'smartcontact'); ?></p>
                        
                        <table class="form-table" style="width: 100% !important; display: table !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                            <tr>
                                <th scope="row">
                                    <label for="form_title"><?php _e('Form Title', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <input type="text" id="form_title" name="smartcontact_settings[form_title]" value="<?php echo esc_attr($options['form_title'] ?? 'Get in Touch'); ?>" class="regular-text" />
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="form_description"><?php _e('Form Description', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <textarea id="form_description" name="smartcontact_settings[form_description]" rows="3" cols="50"><?php echo esc_textarea($options['form_description'] ?? 'Send us a message and we\'ll respond as soon as possible.'); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="theme"><?php _e('Theme', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <select id="theme" name="smartcontact_settings[theme]" class="theme-selector">
                                        <option value="skyblue" <?php selected($options['theme'] ?? 'skyblue', 'skyblue'); ?>>
                                            <span class="theme-icon skyblue-icon"></span> <?php _e('Sky Blue', 'smartcontact'); ?>
                                        </option>
                                        <option value="pink" <?php selected($options['theme'] ?? 'skyblue', 'pink'); ?>>
                                            <span class="theme-icon pink-icon"></span> <?php _e('Pink', 'smartcontact'); ?>
                                        </option>
                                        <option value="orange" <?php selected($options['theme'] ?? 'skyblue', 'orange'); ?>>
                                            <span class="theme-icon orange-icon"></span> <?php _e('Orange', 'smartcontact'); ?>
                                        </option>
                                        <option value="grey" <?php selected($options['theme'] ?? 'skyblue', 'grey'); ?>>
                                            <span class="theme-icon grey-icon"></span> <?php _e('Grey', 'smartcontact'); ?>
                                        </option>

                                    </select>
                                    <div class="theme-preview">
                                        <div class="theme-preview-item skyblue-preview" data-theme="skyblue">
                                            <div class="theme-color-box skyblue-color"></div>
                                            <span><?php _e('Sky Blue', 'smartcontact'); ?></span>
                                        </div>
                                        <div class="theme-preview-item pink-preview" data-theme="pink">
                                            <div class="theme-color-box pink-color"></div>
                                            <span><?php _e('Pink', 'smartcontact'); ?></span>
                                        </div>
                                        <div class="theme-preview-item orange-preview" data-theme="orange">
                                            <div class="theme-color-box orange-color"></div>
                                            <span><?php _e('Orange', 'smartcontact'); ?></span>
                                        </div>
                                        <div class="theme-preview-item grey-preview" data-theme="grey">
                                            <div class="theme-color-box grey-color"></div>
                                            <span><?php _e('Grey', 'smartcontact'); ?></span>
                                        </div>

                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="captcha_enabled"><?php _e('Enable CAPTCHA', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <input type="checkbox" id="captcha_enabled" name="smartcontact_settings[captcha_enabled]" value="1" <?php checked($options['captcha_enabled'] ?? true); ?> />
                                    <span class="description"><?php _e('Add a simple math CAPTCHA to prevent spam', 'smartcontact'); ?></span>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- Custom Fields Section -->
                    <div class="smartcontact-admin-section" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                        <h2><?php _e('Custom Form Fields', 'smartcontact'); ?></h2>
                        <p class="description"><?php _e('Add custom fields to your contact form. These will appear after the default fields.', 'smartcontact'); ?></p>

                        <div id="custom-fields-container">
                            <?php
                            $custom_fields = $options['custom_fields'] ?? array();
                            if (empty($custom_fields)):
                            ?>
                                <p id="no-fields-message"><?php _e('No custom fields added yet.', 'smartcontact'); ?></p>
                            <?php else: ?>
                                <?php foreach ($custom_fields as $index => $field): ?>
                                    <div class="custom-field-row" data-index="<?php echo $index; ?>">
                                        <div class="field-controls">
                                            <div class="field-group">
                                                <label><?php _e('Field Label:', 'smartcontact'); ?></label>
                                                <input type="text" name="custom_fields[<?php echo $index; ?>][label]" value="<?php echo esc_attr($field['label']); ?>" placeholder="<?php _e('e.g., Company Name', 'smartcontact'); ?>">
                                            </div>

                                            <div class="field-group">
                                                <label><?php _e('Field Type:', 'smartcontact'); ?></label>
                                                <select name="custom_fields[<?php echo $index; ?>][type]">
                                                    <option value="text" <?php selected($field['type'], 'text'); ?>><?php _e('Text (accepts all data)', 'smartcontact'); ?></option>
                                                    <option value="dropdown" <?php selected($field['type'], 'dropdown'); ?>><?php _e('Dropdown (multiple choice)', 'smartcontact'); ?></option>
                                                </select>
                                            </div>

                                            <div class="field-group">
                                                <label><?php _e('Placeholder:', 'smartcontact'); ?></label>
                                                <input type="text" name="custom_fields[<?php echo $index; ?>][placeholder]" value="<?php echo esc_attr($field['placeholder']); ?>" placeholder="<?php _e('e.g., Enter your company name', 'smartcontact'); ?>">
                                            </div>

                                            <div class="field-group dropdown-options" style="display: <?php echo $field['type'] === 'dropdown' ? 'block' : 'none'; ?>;">
                                                <label><?php _e('Dropdown Options (one per line):', 'smartcontact'); ?></label>
                                                <textarea name="custom_fields[<?php echo $index; ?>][options]" rows="3" placeholder="Option 1&#10;Option 2&#10;Option 3"><?php echo esc_textarea($field['options'] ?? ''); ?></textarea>
                                                <small><?php _e('Enter each option on a new line', 'smartcontact'); ?></small>
                                            </div>

                                            <div class="field-group">
                                                <label>
                                                    <input type="checkbox" name="custom_fields[<?php echo $index; ?>][required]" value="1" <?php checked($field['required']); ?>>
                                                    <?php _e('Required Field', 'smartcontact'); ?>
                                                </label>
                                            </div>

                                            <div class="field-group">
                                                <button type="button" class="button remove-field"><?php _e('Remove Field', 'smartcontact'); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>

                        <div class="custom-fields-actions">
                            <button type="button" id="add-custom-field" class="button button-secondary"><?php _e('Add Custom Field', 'smartcontact'); ?></button>
                            <button type="button" id="save-custom-fields" class="button button-primary"><?php _e('Save Custom Fields', 'smartcontact'); ?></button>
                        </div>

                        <div id="custom-fields-result" class="smartcontact-test-result"></div>
                    </div>

                    <!-- Shortcode Section -->
                    <div class="smartcontact-admin-section" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                        <h2><?php _e('Shortcode Usage', 'smartcontact'); ?></h2>
                        <p class="description"><?php _e('Use this shortcode to display the contact form on any page or post:', 'smartcontact'); ?></p>
                        
                        <div class="shortcode-display">
                            <div class="shortcode-box">
                                <code id="shortcode-form">[smartcontact_form]</code>
                                <button type="button" class="copy-shortcode-btn" data-target="shortcode-form">
                                    <span class="copy-text"><?php _e('Copy', 'smartcontact'); ?></span>
                                    <span class="copied-text" style="display: none;"><?php _e('Copied!', 'smartcontact'); ?></span>
                                </button>
                            </div>
                            <p class="shortcode-description"><?php _e('This shortcode will display the contact form with your current form settings and custom fields.', 'smartcontact'); ?></p>
                        </div>
                    </div>
                    

                </div>
                
                <!-- Popup Settings Tab -->
                <div id="tab-popup" class="smartcontact-tab-content" style="display: none; width: 100% !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                    <div class="smartcontact-admin-section" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                        <h2><?php _e('Popup Configuration', 'smartcontact'); ?></h2>
                        <p class="description"><?php _e('Configure popup behavior and timing. When enabled, the form will appear as a popup after the specified delay.', 'smartcontact'); ?></p>
                        
                        <table class="form-table" style="width: 100% !important; display: table !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                            <tr>
                                <th scope="row">
                                    <label for="popup_enabled"><?php _e('Enable Popup', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <input type="checkbox" id="popup_enabled" name="smartcontact_settings[popup_enabled]" value="1" <?php checked($options['popup_enabled'] ?? false); ?> />
                                    <span class="description"><?php _e('Show contact form as a popup on all pages', 'smartcontact'); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="popup_delay"><?php _e('Popup Delay (ms)', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <input type="number" id="popup_delay" name="smartcontact_settings[popup_delay]" value="<?php echo esc_attr($options['popup_delay'] ?? 5000); ?>" class="small-text" min="0" />
                                    <span class="description"><?php _e('Time to wait before showing popup (milliseconds)', 'smartcontact'); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="popup_session_delay"><?php _e('Session Delay (seconds)', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <input type="number" id="popup_session_delay" name="smartcontact_settings[popup_session_delay]" value="<?php echo esc_attr($options['popup_session_delay'] ?? 86400); ?>" class="small-text" min="0" />
                                    <span class="description"><?php _e('Time to wait before showing popup again (seconds)', 'smartcontact'); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="session_popup_enabled"><?php _e('Enable Session-based Popup', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <input type="checkbox" id="session_popup_enabled" name="smartcontact_settings[session_popup_enabled]" value="1" <?php checked($options['session_popup_enabled'] ?? false); ?> />
                                    <span class="description"><?php _e('Show popup after user has been browsing for specified time', 'smartcontact'); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="session_popup_time"><?php _e('Session Time (seconds)', 'smartcontact'); ?></label>
                                </th>
                                <td>
                                    <input type="number" id="session_popup_time" name="smartcontact_settings[session_popup_time]" value="<?php echo esc_attr($options['session_popup_time'] ?? 300); ?>" class="small-text" min="0" />
                                    <span class="description"><?php _e('Time user must browse before showing popup (seconds)', 'smartcontact'); ?></span>
                                </td>
                            </tr>
                        </table>
                        
                        <!-- Popup Save Button -->
                        <div class="popup-settings-actions" style="margin: 20px 0; padding: 15px; background: #f0f8ff; border: 1px solid #0073aa; border-radius: 4px;">
                            <button type="button" id="save-popup-settings" class="button button-primary">
                                <span class="dashicons dashicons-yes" style="margin-right: 5px;"></span>
                                <?php _e('Save Popup Settings', 'smartcontact'); ?>
                            </button>
                            <div id="popup-settings-result" class="smartcontact-test-result"></div>
                        </div>
                        
                        <div class="smartcontact-popup-info" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                            <h4><?php _e('Session-based Popup:', 'smartcontact'); ?></h4>
                            <p><?php _e('This feature shows a small notification popup after users have been on your site for a specified time, encouraging them to contact you.', 'smartcontact'); ?></p>
                            <h4><?php _e('Usage Instructions:', 'smartcontact'); ?></h4>
                            <ul>
                                <li><strong><?php _e('Normal Form:', 'smartcontact'); ?></strong> <?php _e('Use shortcode', 'smartcontact'); ?> <code>[smartcontact_form]</code> <?php _e('in any page or post', 'smartcontact'); ?></li>
                                <li><strong><?php _e('Popup Form:', 'smartcontact'); ?></strong> <?php _e('Use shortcode', 'smartcontact'); ?> <code>[smartcontact_form_popup]</code> <?php _e('in any page or post to show the form as a popup. You can use both shortcodes on the same page if needed.', 'smartcontact'); ?></li>
                                <li><strong><?php _e('Session Popup:', 'smartcontact'); ?></strong> <?php _e('Enable session popup to show after user browses for specified time (requires popup enabled).', 'smartcontact'); ?></li>
                                <li><strong><?php _e('Custom Shortcode:', 'smartcontact'); ?></strong> <code>[smartcontact_form_popup title="Custom Title" description="Custom description" theme="pink"]</code></li>
                            </ul>
                            <div class="smartcontact-popup-debug" style="margin-top: 20px; padding: 15px; background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 4px;">
                                <h4><?php _e('Testing Popup:', 'smartcontact'); ?></h4>
                                <p><?php _e('If popup is not showing, it might be because a cookie was set from a previous test. Clear your browser cookies for this site or use this button:', 'smartcontact'); ?></p>
                                <button type="button" id="clear-popup-cookie" class="button button-secondary"><?php _e('Clear Popup Cookie', 'smartcontact'); ?></button>
                                <p><small><?php _e('This will allow the popup to show again for testing purposes.', 'smartcontact'); ?></small></p>
                            </div>
                        </div>
                    </div>

                    <!-- Shortcode Section -->
                    <div class="smartcontact-admin-section" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important;">
                        <h2><?php _e('Shortcode Usage', 'smartcontact'); ?></h2>
                        <p class="description"><?php _e('Use this shortcode to display the contact form on any page or post:', 'smartcontact'); ?></p>
                        
                        <div class="shortcode-display">
                            <div class="shortcode-box">
                                <code id="shortcode-form">[smartcontact_form]</code>
                                <button type="button" class="copy-shortcode-btn" data-target="shortcode-form">
                                    <span class="copy-text"><?php _e('Copy', 'smartcontact'); ?></span>
                                    <span class="copied-text" style="display: none;"><?php _e('Copied!', 'smartcontact'); ?></span>
                                </button>
                            </div>
                            <p class="shortcode-description"><?php _e('This shortcode will display the contact form with your current form settings and custom fields.', 'smartcontact'); ?></p>
                        </div>
                    </div>
                    

                </div>
                

                
                <!-- Bottom Save Settings Button -->
                <div class="smartcontact-save-bottom" style="width: 100% !important; display: block !important; position: static !important; overflow: visible !important; float: none !important; clear: both !important; padding: 20px 30px; background: #f9f9f9; border-top: 1px solid #ccd0d4; margin: 30px -30px -30px -30px;">
                    <?php submit_button(__('Save Settings', 'smartcontact'), 'primary', 'submit', false, array('id' => 'submit-bottom')); ?>
                </div>
            </form>
            </form>
        </div>
    </div>
</div>


