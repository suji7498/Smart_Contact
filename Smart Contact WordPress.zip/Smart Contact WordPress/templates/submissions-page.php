<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Get plugin instance to access JSON methods
$plugin = new SmartContactWebhookForm();

// Handle individual deletion
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $submission_id = intval($_GET['id']);
    if (wp_verify_nonce($_GET['_wpnonce'], 'delete_submission_' . $submission_id)) {
        if ($plugin->delete_submission($submission_id)) {
            echo '<div class="notice notice-success"><p>' . __('Submission deleted successfully.', 'smartcontact') . '</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>' . __('Failed to delete submission.', 'smartcontact') . '</p></div>';
        }
        
        // Redirect to remove the action parameters from URL
        wp_redirect(admin_url('admin.php?page=smartcontact-submissions'));
        exit;
    } else {
        echo '<div class="notice notice-error"><p>' . __('Security check failed. Please try again.', 'smartcontact') . '</p></div>';
    }
}

// Handle pagination
$items_per_page = 20;
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($current_page - 1) * $items_per_page;

$total_items = $plugin->get_submission_count();
$total_pages = ceil($total_items / $items_per_page);

// Get submissions
$submissions = $plugin->get_submissions($items_per_page, $offset);

// Handle bulk actions
if (isset($_POST['action']) && $_POST['action'] === 'delete_selected' && isset($_POST['submission_ids'])) {
    if (wp_verify_nonce($_POST['_wpnonce'], 'bulk_action_submissions')) {
        $ids = array_map('intval', $_POST['submission_ids']);
        
        $deleted_count = 0;
        foreach ($ids as $id) {
            if ($plugin->delete_submission($id)) {
                $deleted_count++;
            }
        }
        
        if ($deleted_count > 0) {
            echo '<div class="notice notice-success"><p>' . sprintf(__('%d submissions deleted.', 'smartcontact'), $deleted_count) . '</p></div>';
        }
    }
}


?>

<div class="wrap">
    <h1 class="wp-heading-inline"><?php _e('Form Submissions', 'smartcontact'); ?></h1>
    
    <?php if (isset($_GET['webhook_result'])): ?>
        <div class="notice notice-info is-dismissible">
            <p><?php echo esc_html(urldecode($_GET['webhook_result'])); ?></p>
        </div>
    <?php endif; ?>
    
    <?php if ($total_items > 0): ?>
    <a href="<?php echo add_query_arg('action', 'export'); ?>" class="page-title-action smartcontact-export-btn" 
       title="<?php printf(__('Export all %d submissions to CSV file', 'smartcontact'), $total_items); ?>"
       data-count="<?php echo $total_items; ?>">
        <span class="dashicons dashicons-download" style="margin-right: 5px; vertical-align: middle;"></span>
        <?php printf(__('Export CSV (%d)', 'smartcontact'), $total_items); ?>
    </a>
    <?php endif; ?>
    

    
    <hr class="wp-header-end">
    
    <?php if (empty($submissions)): ?>
        <div class="smartcontact-empty-state">
            <div class="smartcontact-empty-content">
                <div class="dashicons dashicons-email-alt smartcontact-empty-icon"></div>
                <h3><?php _e('No submissions yet', 'smartcontact'); ?></h3>
                <p><?php _e('Form submissions will appear here once people start using your contact form.', 'smartcontact'); ?></p>
                <a href="<?php echo admin_url('admin.php?page=smartcontact-settings'); ?>" class="button button-primary">
                    <?php _e('Configure Form', 'smartcontact'); ?>
                </a>
            </div>
        </div>
    <?php else: ?>
        <form method="post">
            <?php wp_nonce_field('bulk_action_submissions'); ?>
            
            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    <select name="action">
                        <option value="-1"><?php _e('Bulk Actions', 'smartcontact'); ?></option>
                        <option value="delete_selected"><?php _e('Delete', 'smartcontact'); ?></option>
                        <option value="resend_webhook"><?php _e('Submit To Webhook', 'smartcontact'); ?></option>
                    </select>
                    <input type="submit" class="button action" value="<?php _e('Apply', 'smartcontact'); ?>">

                    <a href="<?php echo add_query_arg('action', 'export'); ?>" class="button button-secondary smartcontact-export-btn" 
                       style="margin-left: 10px;" data-count="<?php echo $total_items; ?>">
                        <span class="dashicons dashicons-download" style="margin-right: 3px; vertical-align: middle; font-size: 16px; width: 16px; height: 16px;"></span>
                        <?php _e('Export All to CSV', 'smartcontact'); ?>
                    </a>
                    
                    <button type="button" id="import-csv-btn" class="button button-secondary smartcontact-import-btn" 
                            style="margin-left: 10px;">
                        <span class="dashicons dashicons-upload" style="margin-right: 3px; vertical-align: middle; font-size: 16px; width: 16px; height: 16px;"></span>
                        <?php _e('Import from CSV', 'smartcontact'); ?>
                    </button>
                </div>
                
                <div class="tablenav-pages">
                    <span class="displaying-num">
                        <?php printf(_n('%s item', '%s items', $total_items, 'smartcontact'), number_format_i18n($total_items)); ?>
                    </span>
                    
                    <?php if ($total_pages > 1): ?>
                        <span class="pagination-links">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page
                            ));
                            ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <td class="manage-column column-cb check-column">
                            <input type="checkbox" id="cb-select-all-1">
                        </td>
                        <th class="manage-column"><?php _e('Name', 'smartcontact'); ?></th>
                        <th class="manage-column"><?php _e('Email', 'smartcontact'); ?></th>
                        <th class="manage-column"><?php _e('Subject', 'smartcontact'); ?></th>
                        <th class="manage-column"><?php _e('Message', 'smartcontact'); ?></th>
                        <th class="manage-column"><?php _e('Page Info', 'smartcontact'); ?></th>
                        <th class="manage-column"><?php _e('Date', 'smartcontact'); ?></th>
                        <th class="manage-column"><?php _e('Webhook Status', 'smartcontact'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <th scope="row" class="check-column">
                                <input type="checkbox" name="submission_ids[]" value="<?php echo $submission['id']; ?>">
                            </th>
                            <td>
                                <strong><?php echo esc_html($submission['name']); ?></strong>
                                <div class="row-actions">
                                    <span class="view">
                                        <a href="#" class="view-submission" data-id="<?php echo $submission['id']; ?>">
                                            <?php _e('View', 'smartcontact'); ?>
                                        </a> |
                                    </span>
                                    <span class="delete">
                                        <a href="<?php echo wp_nonce_url(add_query_arg(array('action' => 'delete', 'id' => $submission['id'])), 'delete_submission_' . $submission['id']); ?>" 
                                           onclick="return confirm('<?php _e('Are you sure?', 'smartcontact'); ?>')">
                                            <?php _e('Delete', 'smartcontact'); ?>
                                        </a>
                                    </span>
                                </div>
                            </td>
                            <td>
                                <a href="mailto:<?php echo esc_attr($submission['email']); ?>">
                                    <?php echo esc_html($submission['email']); ?>
                                </a>
                            </td>
                            <td><?php echo esc_html($submission['subject'] ?: __('No subject', 'smartcontact')); ?></td>
                            <td>
                                <div class="smartcontact-message-preview">
                                    <?php echo esc_html(wp_trim_words($submission['message'], 10)); ?>
                                    <?php if (str_word_count($submission['message']) > 10): ?>
                                        <a href="#" class="view-full-message" data-message="<?php echo esc_attr($submission['message']); ?>">
                                            <?php _e('Read more', 'smartcontact'); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div class="page-tracking-info">
                                    <?php if ($submission['page_title'] || $submission['page_url']): ?>
                                        <div class="page-info">
                                            <?php if ($submission['page_title']): ?>
                                                <strong><?php echo esc_html($submission['page_title']); ?></strong><br>
                                            <?php endif; ?>
                                            <?php if ($submission['page_url']): ?>
                                                <a href="<?php echo esc_url($submission['page_url']); ?>" target="_blank" title="<?php echo esc_attr($submission['page_url']); ?>">
                                                    <?php echo esc_html(wp_trim_words($submission['page_url'], 6, '...')); ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>

                                        <?php
                                        // Show custom fields if any
                                        if ($submission['custom_fields']) {
                                            if (is_array($submission['custom_fields']) && !empty($submission['custom_fields'])) {
                                                echo '<div class="custom-fields-preview" style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #eee;">';
                                                echo '<small><strong>Custom Fields:</strong></small><br>';
                                                $count = 0;
                                                foreach ($submission['custom_fields'] as $field_name => $field_value) {
                                                    if ($count >= 1) {
                                                        echo '<small>+' . (count($submission['custom_fields']) - 1) . ' more...</small>';
                                                        break;
                                                    }
                                                    echo '<small>' . esc_html($field_name) . ': ' . esc_html($field_value) . '</small><br>';
                                                    $count++;
                                                }
                                                echo '</div>';
                                            }
                                        }
                                        ?>
                                    <?php else: ?>
                                        <em><?php _e('No page info', 'smartcontact'); ?></em>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <abbr title="<?php echo esc_attr($submission['submission_time']); ?>">
                                    <?php echo human_time_diff(strtotime($submission['submission_time']), current_time('timestamp')) . ' ' . __('ago', 'smartcontact'); ?>
                                </abbr>
                            </td>
                            <td>
                                <?php if ($submission['webhook_response']): ?>
                                    <?php
                                    $response = $submission['webhook_response'];
                                    if (is_array($response) && isset($response['status_code']) && $response['status_code'] >= 200 && $response['status_code'] < 300):
                                    ?>
                                        <span class="smartcontact-status-success">✓ <?php _e('Sent', 'smartcontact'); ?></span>
                                    <?php else: ?>
                                        <span class="smartcontact-status-error">✗ <?php _e('Failed', 'smartcontact'); ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="smartcontact-status-pending">— <?php _e('No webhook', 'smartcontact'); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php if ($total_pages > 1): ?>
                        <span class="pagination-links">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page
                            ));
                            ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    <?php endif; ?>
</div>

<!-- Modal for viewing full message -->
<div id="smartcontact-message-modal" class="smartcontact-modal" style="display: none;">
    <div class="smartcontact-modal-content">
        <span class="smartcontact-modal-close">&times;</span>
        <h3><?php _e('Full Message', 'smartcontact'); ?></h3>
        <div id="smartcontact-modal-message"></div>
    </div>
</div>

<!-- Modal for CSV Import -->
<div id="smartcontact-import-modal" class="smartcontact-modal" style="display: none;">
    <div class="smartcontact-modal-content" style="max-width: 600px;">
        <span class="smartcontact-modal-close">&times;</span>
        <h3><?php _e('Import Submissions from CSV', 'smartcontact'); ?></h3>
        
        <div class="import-instructions" style="margin-bottom: 20px; padding: 15px; background: #f0f8ff; border-radius: 6px;">
            <h4><?php _e('Instructions:', 'smartcontact'); ?></h4>
            <ul style="margin: 10px 0; padding-left: 20px;">
                <li><?php _e('Upload a CSV file with the same format as exported data', 'smartcontact'); ?></li>
                <li><?php _e('Required columns: Name, Email, Subject, Message', 'smartcontact'); ?></li>
                <li><?php _e('Optional columns: Page URL, Page Title, Referrer URL, Submission Time, IP Address', 'smartcontact'); ?></li>
                <li><?php _e('Custom field columns will be automatically detected', 'smartcontact'); ?></li>
                <li><?php _e('Existing submissions will not be overwritten', 'smartcontact'); ?></li>
            </ul>
        </div>
        
        <form id="csv-import-form" enctype="multipart/form-data">
            <?php wp_nonce_field('smartcontact_import_csv', 'import_nonce'); ?>
            
            <div class="form-field" style="margin-bottom: 20px;">
                <label for="csv-file" style="display: block; margin-bottom: 8px; font-weight: 600;">
                    <?php _e('Select CSV File:', 'smartcontact'); ?>
                </label>
                <input type="file" id="csv-file" name="csv_file" accept=".csv" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            
            <div class="import-options" style="margin-bottom: 20px;">
                <h4><?php _e('Import Options:', 'smartcontact'); ?></h4>
                <label style="display: block; margin: 8px 0;">
                    <input type="checkbox" id="skip-duplicates" name="skip_duplicates" checked>
                    <?php _e('Skip duplicate entries (based on email + submission time)', 'smartcontact'); ?>
                </label>
                <label style="display: block; margin: 8px 0;">
                    <input type="checkbox" id="generate-ids" name="generate_ids" checked>
                    <?php _e('Generate new IDs for imported submissions', 'smartcontact'); ?>
                </label>
            </div>
            
            <div class="import-preview" style="display: none; margin-bottom: 20px;">
                <h4><?php _e('Preview (first 3 rows):', 'smartcontact'); ?></h4>
                <div id="import-preview-content" style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #f9f9f9;"></div>
            </div>
            
            <div class="import-actions" style="text-align: right;">
                <button type="button" class="button button-secondary" onclick="closeImportModal()">
                    <?php _e('Cancel', 'smartcontact'); ?>
                </button>
                <button type="submit" class="button button-primary" id="start-import-btn">
                    <span class="dashicons dashicons-upload" style="margin-right: 5px;"></span>
                    <?php _e('Start Import', 'smartcontact'); ?>
                </button>
            </div>
        </form>
        
        <div id="import-progress" style="display: none; margin-top: 20px;">
            <div class="progress-bar" style="width: 100%; height: 20px; background: #f0f0f0; border-radius: 10px; overflow: hidden;">
                <div class="progress-fill" style="width: 0%; height: 100%; background: #0073aa; transition: width 0.3s;"></div>
            </div>
            <div id="import-status" style="margin-top: 10px; text-align: center;"></div>
        </div>
    </div>
</div>



<script>
jQuery(document).ready(function($) {
    // Export confirmation for large datasets
    $('.smartcontact-export-btn').on('click', function(e) {
        var count = $(this).data('count');
        var $btn = $(this);
        
        if (count > 100) {
            if (!confirm('You are about to export ' + count + ' submissions. This may take a moment. Continue?')) {
                e.preventDefault();
                return false;
            }
        }
        
        // Add visual feedback
        var originalText = $btn.html();
        $btn.html('<span class="dashicons dashicons-update" style="animation: spin 1s linear infinite; margin-right: 5px;"></span> Exporting...');
        $btn.addClass('disabled').css('pointer-events', 'none');
        
        // The browser will handle the download, so we need to reset the button after a delay
        setTimeout(function() {
            $btn.html(originalText);
            $btn.removeClass('disabled').css('pointer-events', 'auto');
        }, 3000);
    });
    
    // Import CSV functionality
    $('#import-csv-btn').on('click', function() {
        $('#smartcontact-import-modal').fadeIn(300);
    });
    
    // Close import modal
    $('.smartcontact-modal-close, .button-secondary').on('click', function() {
        if ($(this).hasClass('button-secondary') && !$(this).attr('onclick')) {
            $('#smartcontact-import-modal').fadeOut(300);
        }
    });
    
    // CSV file preview
    $('#csv-file').on('change', function() {
        var file = this.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                var csv = e.target.result;
                var lines = csv.split('\n');
                var preview = '<table style="width: 100%; border-collapse: collapse;">';
                
                // Show first 4 rows (header + 3 data rows)
                for (var i = 0; i < Math.min(4, lines.length); i++) {
                    var cells = lines[i].split(',');
                    preview += '<tr>';
                    cells.forEach(function(cell) {
                        preview += '<td style="border: 1px solid #ddd; padding: 4px; font-size: 12px;">' + cell.trim().replace(/"/g, '') + '</td>';
                    });
                    preview += '</tr>';
                }
                preview += '</table>';
                
                $('#import-preview-content').html(preview);
                $('.import-preview').show();
            };
            reader.readAsText(file);
        }
    });
    
    // Handle CSV import form submission
    $('#csv-import-form').on('submit', function(e) {
        e.preventDefault();
        
        var formData = new FormData(this);
        var $btn = $('#start-import-btn');
        var originalText = $btn.html();
        
        // Show progress
        $btn.html('<span class="dashicons dashicons-update" style="animation: spin 1s linear infinite; margin-right: 5px;"></span> Importing...').prop('disabled', true);
        $('#import-progress').show();
        $('#import-status').html('Uploading file...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    $('#import-status').html('<span style="color: green;">✓ ' + response.data.message + '</span>');
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    $('#import-status').html('<span style="color: red;">✗ ' + response.data + '</span>');
                }
            },
            error: function() {
                $('#import-status').html('<span style="color: red;">✗ Import failed. Please try again.</span>');
            },
            complete: function() {
                $btn.html(originalText).prop('disabled', false);
            }
        });
    });
});

function closeImportModal() {
    jQuery('#smartcontact-import-modal').fadeOut(300);
}
</script>

<style>
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.smartcontact-export-btn.disabled {
    opacity: 0.7;
}

.smartcontact-export-btn:hover {
    background-color: #f0f0f1;
}

.page-title-action.smartcontact-export-btn:hover {
    background-color: #f0f0f1;
    color: #0073aa;
}
</style>
