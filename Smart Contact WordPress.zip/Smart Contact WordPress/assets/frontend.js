jQuery(document).ready(function($) {
    'use strict';
    
    // Handle form submission
    $(document).on('submit', '#smartcontact-form', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $submitBtn = $form.find('.smartcontact-submit-btn');
        const $messageContainer = $form.find('.smartcontact-message-container');
        const $message = $form.find('.smartcontact-message');
        
        // Show loading state
        $submitBtn.addClass('loading').prop('disabled', true);
        $messageContainer.hide();
        
        // Validate form
        const name = $form.find('[name="name"]').val().trim();
        const email = $form.find('[name="email"]').val().trim();
        const message = $form.find('[name="message"]').val().trim();
        const captcha = $form.find('[name="captcha"]').val();
        const captchaAnswer = $form.find('[name="captcha_answer"]').val();
        
        if (!name || !email || !message) {
            showMessage(smartcontact.strings.required_fields, 'error');
            resetForm();
            return;
        }
        
        if (!isValidEmail(email)) {
            showMessage(smartcontact.strings.invalid_email, 'error');
            resetForm();
            return;
        }
        
        if (captcha && captchaAnswer && parseInt(captcha) !== parseInt(captchaAnswer)) {
            showMessage(smartcontact.strings.captcha_error, 'error');
            resetForm();
            generateNewCaptcha();
            return;
        }
        
        // Collect custom fields data
        const customFields = {};
        $form.find('[name^="custom_"]').each(function() {
            const fieldName = $(this).attr('name');
            const fieldValue = $(this).val().trim();
            if (fieldValue) {
                customFields[fieldName] = fieldValue;
            }
        });
        
        // Submit form via AJAX
        const formData = {
            action: 'smartcontact_submit',
            smartcontact_nonce: smartcontact.nonce,
            name: name,
            email: email,
            subject: $form.find('[name="subject"]').val(),
            message: message,
            captcha: captcha,
            captcha_answer: captchaAnswer,
            ...customFields
        };
        
        $.post(smartcontact.ajax_url, formData)
            .done(function(response) {
                if (response.success) {
                    showMessage(smartcontact.strings.success, 'success');
                    $form[0].reset();
                    generateNewCaptcha();
                    
                    // Close popup if it's in popup mode
                    if ($form.closest('#smartcontact-popup-overlay').length) {
                        setTimeout(function() {
                            closePopup();
                        }, 2000);
                    }
                } else {
                    showMessage(response.data || smartcontact.strings.error, 'error');
                }
            })
            .fail(function() {
                showMessage(smartcontact.strings.error, 'error');
            })
            .always(function() {
                resetForm();
            });
        
        function showMessage(text, type) {
            $message.removeClass('success error').addClass(type).text(text);
            $messageContainer.show();
        }
        
        function resetForm() {
            $submitBtn.removeClass('loading').prop('disabled', false);
        }
    });
    
    // Email validation
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    // Generate new CAPTCHA
    function generateNewCaptcha() {
        const $captchaQuestion = $('.smartcontact-captcha-question');
        const $captchaAnswer = $('[name="captcha_answer"]');
        
        if ($captchaQuestion.length) {
            const num1 = Math.floor(Math.random() * 10) + 1;
            const num2 = Math.floor(Math.random() * 10) + 1;
            
            $captchaQuestion.text(num1 + ' + ' + num2 + ' = ?');
            $captchaAnswer.val(num1 + num2);
            $('[name="captcha"]').val('');
        }
    }
    
    // Popup functionality
    // Only initialize popup if the popup overlay exists in DOM (i.e., [smartcontact_form_popup] is used)
    if ($('#smartcontact-popup-overlay').length) {
        $('#smartcontact-popup-overlay').hide(); // Ensure hidden by default
        // Show popup if not already shown (cookie logic)
        if (typeof smartcontact !== 'undefined' && smartcontact.popup_enabled) {
            initPopup();
        } else {
            // If this is a manual popup (from shortcode), show immediately
            $('#smartcontact-popup-overlay').fadeIn(300);
        }
    }
    
    function initPopup() {
        console.log('SmartContact: Initializing popup...');
        
        // Check if popup should be shown
        const cookieValue = getCookie('smartcontact_popup_shown');
        console.log('SmartContact: Cookie value:', cookieValue);
        
        if (cookieValue) {
            console.log('SmartContact: Popup already shown, skipping...');
            return;
        }
        
        // Check if popup element exists
        if ($('#smartcontact-popup-overlay').length === 0) {
            console.log('SmartContact: Popup overlay not found in DOM');
            return;
        }
        
        console.log('SmartContact: Setting popup timer for', smartcontact.popup_delay, 'ms');
        
        // Show popup after delay
        setTimeout(function() {
            console.log('SmartContact: Showing popup...');
            $('#smartcontact-popup-overlay').fadeIn(300);
            
            // Set cookie to prevent showing again
            const sessionDelay = smartcontact.popup_session_delay || 86400; // 24 hours default
            setCookie('smartcontact_popup_shown', '1', sessionDelay);
            console.log('SmartContact: Cookie set for', sessionDelay, 'seconds');
        }, smartcontact.popup_delay || 5000);
    }
    
    // Close popup handlers
    $(document).on('click', '.smartcontact-popup-close', function(e) {
        e.preventDefault();
        e.stopPropagation();
        closePopup();
    });
    
    $(document).on('click', '.smartcontact-popup-overlay', function(e) {
        if (e.target === this) {
            closePopup();
        }
    });
    
    $(document).on('keyup', function(e) {
        if (e.key === 'Escape') {
            closePopup();
        }
    });
    
    function closePopup() {
        $('#smartcontact-popup-overlay').fadeOut(300);
    }
    
    // Cookie utilities
    function setCookie(name, value, seconds) {
        const date = new Date();
        date.setTime(date.getTime() + (seconds * 1000));
        const expires = "expires=" + date.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }
    
    function getCookie(name) {
        const nameEQ = name + "=";
        const ca = document.cookie.split(';');
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }
    
    // Form animations
    $('.smartcontact-input, .smartcontact-textarea').on('focus', function() {
        $(this).parent().addClass('focused');
    }).on('blur', function() {
        if (!$(this).val()) {
            $(this).parent().removeClass('focused');
        }
    });
    
    // Auto-resize textarea
    $('.smartcontact-textarea').on('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });
    
    // Smooth scroll to form on page load if hash is present
    if (window.location.hash === '#contact') {
        setTimeout(function() {
            $('html, body').animate({
                scrollTop: $('#smartcontact-form').offset().top - 100
            }, 500);
        }, 100);
    }
});
