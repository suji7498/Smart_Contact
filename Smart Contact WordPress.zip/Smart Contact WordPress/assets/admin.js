jQuery(document).ready(function($) {
    'use strict';
    
    // Immediately disable all form validation except the main admin form
    $(document).ready(function() {
        // Disable validation on all forms except the main admin form
        $('form:not([action="options.php"])').attr('novalidate', 'novalidate');
        
        // Remove all validation attributes from non-admin forms
        $('form:not([action="options.php"]) input, form:not([action="options.php"]) textarea, form:not([action="options.php"]) select').each(function() {
            $(this).removeAttr('required');
            $(this).removeAttr('pattern');
            $(this).removeAttr('min');
            $(this).removeAttr('max');
            $(this).removeAttr('minlength');
            $(this).removeAttr('maxlength');
        });
        
        // Prevent any form validation events on non-admin forms
        $(document).on('invalid', 'form:not([action="options.php"])', function(e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        });
        
        // AGGRESSIVE: Remove any smartcontact form elements that might cause conflicts
        function removePreviewForms() {
            $('#smartcontact-form').remove();
            $('#smartcontact-popup-overlay').remove();
            $('.smartcontact-form-container').remove();
            $('[id*="smartcontact-"]').not('[id*="smartcontact-admin"]').not('[id*="smartcontact-settings"]').remove();
        }
        
        // Run immediately and also set up a periodic check
        removePreviewForms();
        setInterval(removePreviewForms, 1000);
    });
    
    // Tab switching functionality
    $('.nav-tab').on('click', function(e) {
        e.preventDefault();
        
        var targetTab = $(this).data('tab');
        
        // Remove active class from all tabs and hide all content
        $('.nav-tab').removeClass('nav-tab-active');
        $('.smartcontact-tab-content').hide();
        
        // Add active class to clicked tab and show corresponding content
        $(this).addClass('nav-tab-active');
        $('#tab-' + targetTab).show();
        
        // Show/hide save buttons based on tab
        toggleSaveButtons(targetTab);
        
        // Update URL hash without triggering beforeunload
        if (history.pushState) {
            history.pushState(null, null, '#' + targetTab);
        } else {
            window.location.hash = targetTab;
        }
    });
    
    // Function to show/hide save buttons based on active tab
    function toggleSaveButtons(activeTab) {
        // Show/hide save buttons based on active tab
        if (activeTab === 'webhook' || activeTab === 'form') {
            $('.smartcontact-save-buttons').show();
            $('.smartcontact-save-bottom').show();
        } else {
            $('.smartcontact-save-buttons').hide();
            $('.smartcontact-save-bottom').hide();
        }
        
        // COMPLETELY REMOVE preview form and all its elements when not on preview tab
        if (activeTab !== 'preview') {
            $('#smartcontact-form').remove();
            $('#smartcontact-popup-overlay').remove();
            $('.smartcontact-form-container').remove();
            // Also remove any dynamically added preview elements
            $('[id*="smartcontact-"]').not('[id*="smartcontact-admin"]').remove();
        }
    }
    
    // Initialize tab based on URL hash or default to webhook
    function initializeTab() {
        var hash = window.location.hash.substring(1);
        var validTabs = ['webhook', 'form', 'popup', 'import-export'];
        
        if (validTabs.includes(hash)) {
            // Switch to the tab without triggering click event
            $('.nav-tab').removeClass('nav-tab-active');
            $('.smartcontact-tab-content').hide();
            $('.nav-tab[data-tab="' + hash + '"]').addClass('nav-tab-active');
            $('#tab-' + hash).show();
            // Show/hide save buttons for initial tab
            toggleSaveButtons(hash);
        } else {
            // Default to webhook tab if no valid hash
            $('.nav-tab').removeClass('nav-tab-active');
            $('.smartcontact-tab-content').hide();
            $('.nav-tab[data-tab="webhook"]').addClass('nav-tab-active');
            $('#tab-webhook').show();
            // Show save buttons for default webhook tab
            toggleSaveButtons('webhook');
        }
    }
    
    // Initialize on page load
    initializeTab();
    
    // Test webhook functionality
    $('#test-webhook-btn').on('click', function() {
        var $btn = $(this);
        var $result = $('#webhook-test-result');
        var webhookUrl = $('#webhook_url').val();
        var webhookMethod = $('#webhook_method').val();
        
        if (!webhookUrl) {
            $result.removeClass('success').addClass('error').html('Please enter a webhook URL first.').show();
            return;
        }
        
        $btn.prop('disabled', true).text('Testing...');
        $result.removeClass('success error').html('Testing webhook...').show();
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            timeout: 30000, // 30 seconds timeout
            data: {
                action: 'smartcontact_test_webhook',
                webhook_url: webhookUrl,
                webhook_method: webhookMethod,
                nonce: smartcontact_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $result.removeClass('error').addClass('success').html('✅ Webhook test successful! Response: ' + response.data.message).show();
                } else {
                    $result.removeClass('success').addClass('error').html('❌ Webhook test failed: ' + response.data.message).show();
                }
            },
            error: function(xhr, status, error) {
                var errorMsg = '❌ Webhook test failed: ';
                if (status === 'timeout') {
                    errorMsg += 'Request timed out after 30 seconds. Your webhook server might be slow to respond.';
                } else if (status === 'error') {
                    errorMsg += 'Network error. Please check your webhook URL and server status.';
                } else {
                    errorMsg += 'Network error or server timeout. Status: ' + status;
                }
                $result.removeClass('success').addClass('error').html(errorMsg).show();
            }
        })
        .always(function() {
            $btn.prop('disabled', false).text('Test Webhook');
        });
    });
    
    // Custom fields management
    // Initialize fieldIndex to start after existing fields to prevent duplicates
    var fieldIndex = $('.custom-field-row').length;
    
    $('#add-custom-field').on('click', function() {
        var newField = `
            <div class="custom-field-row" data-index="${fieldIndex}">
                <div class="field-controls">
                    <div class="field-group">
                        <label>Field Label:</label>
                        <input type="text" name="custom_fields[${fieldIndex}][label]" placeholder="e.g., Company Name">
                    </div>
                    <div class="field-group">
                        <label>Field Type:</label>
                        <select name="custom_fields[${fieldIndex}][type]">
                            <option value="text">Text (accepts all data)</option>
                        </select>
                    </div>
                    <div class="field-group">
                        <label>Placeholder:</label>
                        <input type="text" name="custom_fields[${fieldIndex}][placeholder]" placeholder="e.g., Enter your company name">
                    </div>
                    <div class="field-group">
                        <label>
                            <input type="checkbox" name="custom_fields[${fieldIndex}][required]" value="1">
                            Required Field
                        </label>
                    </div>
                    <div class="field-group">
                        <button type="button" class="button remove-field">Remove Field</button>
                    </div>
                </div>
            </div>
        `;
        
        $('#custom-fields-container').append(newField);
        $('#no-fields-message').hide();
        fieldIndex++;
    });
    
    // Handle field type changes to show/hide dropdown options
    $(document).on('change', 'select[name*="[type]"]', function() {
        var $this = $(this);
        var $row = $this.closest('.custom-field-row');
        var $placeholder = $row.find('input[name*="[placeholder]"]');
        
        if ($this.val() === 'text') {
            $placeholder.attr('placeholder', 'e.g., Enter your company name');
        }
    });
    
    $(document).on('click', '.remove-field', function() {
        $(this).closest('.custom-field-row').remove();
        
        if ($('.custom-field-row').length === 0) {
            $('#no-fields-message').show();
        }
    });
    
    // Save custom fields
    $('#save-custom-fields').on('click', function() {
        var $btn = $(this);
        var $result = $('#custom-fields-result');
        var customFields = [];
        
        $('.custom-field-row').each(function() {
            var $row = $(this);
            var field = {
                label: $row.find('input[name*="[label]"]').val(),
                type: $row.find('select[name*="[type]"]').val(),
                placeholder: $row.find('input[name*="[placeholder]"]').val(),
                required: $row.find('input[name*="[required]"]').is(':checked')
            };
            
            if (field.label) {
                customFields.push(field);
            }
        });
        
        $btn.prop('disabled', true).text('Saving...');
        $result.removeClass('success error').html('Saving custom fields...').show();
        
        $.post(ajaxurl, {
            action: 'smartcontact_save_custom_fields',
            custom_fields: customFields,
            nonce: smartcontact_admin.nonce
        })
        .done(function(response) {
            if (response.success) {
                $result.removeClass('error').addClass('success').html('✅ Custom fields saved successfully!').show();
                // Refresh preview to show new fields
                refreshPreview();
                // Reload custom fields to show saved fields
                setTimeout(function() {
                    reloadCustomFields();
                    // Update originalFormData to prevent false unsaved warning
                    storeOriginalFormData();
                    hasUnsavedChanges = false;
                }, 1000);
            } else {
                $result.removeClass('success').addClass('error').html('❌ Failed to save custom fields: ' + response.data.message).show();
            }
        })
        .fail(function() {
            $result.removeClass('success').addClass('error').html('❌ Failed to save custom fields: Network error.').show();
        })
        .always(function() {
            $btn.prop('disabled', false).text('Save Custom Fields');
        });
    });
    
    // Reload custom fields section to show saved fields
    function reloadCustomFields() {
        $.post(ajaxurl, {
            action: 'smartcontact_get_custom_fields',
            nonce: smartcontact_admin.nonce
        })
        .done(function(response) {
            if (response.success && response.data.html) {
                $('#custom-fields-container').html(response.data.html);
                // Reset field index for new fields
                fieldIndex = $('.custom-field-row').length;
                // Hide the no-fields message if there are fields
                if ($('.custom-field-row').length > 0) {
                    $('#no-fields-message').hide();
                } else {
                    $('#no-fields-message').show();
                }
            }
        })
        .fail(function() {
            console.error('Failed to reload custom fields');
        });
    }
    
    // Refresh preview functionality
    function refreshPreview() {
        // ONLY refresh if we're on the preview tab - STRICT CHECK
        if (!$('#tab-preview').is(':visible') || $('.nav-tab-active').data('tab') !== 'preview') {
            console.log('Preview refresh blocked - not on preview tab');
            return;
        }
        
        var $preview = $('#smartcontact-preview');
        var $refreshBtn = $('#refresh-preview');
        
        $refreshBtn.prop('disabled', true).find('.dashicons').addClass('dashicons-update-spin');
        
        // Show loading state
        $preview.html('<div style="text-align: center; padding: 40px; color: #666;">Loading preview...</div>');
        
        console.log('Refreshing preview...');
        
        // Reload the preview content
        $.post(ajaxurl, {
            action: 'smartcontact_get_form_preview',
            nonce: smartcontact_admin.nonce
        })
        .done(function(response) {
            console.log('Preview response:', response);
            if (response.success) {
                $preview.html(response.data.html);
                // Immediately disable validation on the new preview form
                setTimeout(function() {
                    disablePreviewFormValidation();
                }, 100);
            } else {
                $preview.html('<div style="text-align: center; padding: 40px; color: #dc3232;">Failed to load preview: ' + (response.data || 'Unknown error') + '</div>');
            }
        })
        .fail(function(xhr, status, error) {
            console.error('Preview failed:', xhr, status, error);
            $preview.html('<div style="text-align: center; padding: 40px; color: #dc3232;">Failed to load preview: ' + error + '</div>');
        })
        .always(function() {
            $refreshBtn.prop('disabled', false).find('.dashicons').removeClass('dashicons-update-spin');
        });
    }
    
    // Manual refresh button
    $('#refresh-preview').on('click', function() {
        refreshPreview();
    });
    
    // Auto-refresh preview when form settings change - only if on preview tab
    $('#form_title, #form_description, #theme, #captcha_enabled').on('change', function() {
        // ONLY refresh preview if we're actually on the preview tab
        if ($('#tab-preview').is(':visible') && $('.nav-tab-active').data('tab') === 'preview') {
            // Debounce the refresh to avoid too many requests
            clearTimeout(window.previewRefreshTimeout);
            window.previewRefreshTimeout = setTimeout(function() {
                refreshPreview();
            }, 1000);
        }
        // Do NOT refresh preview when on Form Settings tab to prevent validation conflicts
    });
    
    // Completely disable HTML5 validation on the preview form to prevent conflicts
    function disablePreviewFormValidation() {
        $('#smartcontact-form').attr('novalidate', 'novalidate');
        $('#smartcontact-form input, #smartcontact-form textarea, #smartcontact-form select').each(function() {
            $(this).removeAttr('required');
            $(this).removeAttr('pattern');
            $(this).removeAttr('min');
            $(this).removeAttr('max');
            $(this).removeAttr('minlength');
            $(this).removeAttr('maxlength');
        });
        
        // Also disable the form submission completely
        $('#smartcontact-form').off('submit').on('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        });
    }
    
    // Disable validation on existing preview forms
    disablePreviewFormValidation();
    
    // Use MutationObserver to watch for dynamically added preview forms
    if (window.MutationObserver) {
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.addedNodes.length) {
                    for (var i = 0; i < mutation.addedNodes.length; i++) {
                        var node = mutation.addedNodes[i];
                        if (node.nodeType === 1) { // Element node
                            if ($(node).find('#smartcontact-form').length || $(node).is('#smartcontact-form')) {
                                disablePreviewFormValidation();
                            }
                        }
                    }
                }
            });
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }
    
    // Fallback for older browsers
    $(document).on('DOMNodeInserted', function(e) {
        if ($(e.target).find('#smartcontact-form').length || $(e.target).is('#smartcontact-form')) {
            disablePreviewFormValidation();
        }
    });
    
    // Prevent any form validation except the main admin form
    $(document).on('invalid', 'form:not([action="options.php"])', function(e) {
        e.preventDefault();
        e.stopPropagation();
        return false;
    });
    
    // Disable HTML5 validation on all forms except the main admin form
    $('form:not([action="options.php"])').attr('novalidate', 'novalidate');
    
    // Theme preview functionality
    // 1. Fix popup on save vs. leaving without saving
    // Ensure hasUnsavedChanges is set to false on save, and beforeunload only triggers if unsaved changes exist
    var hasUnsavedChanges = false;
    var originalFormData = {};
    
    // Store original form data on page load - only from webhook and form tabs
    function storeOriginalFormData() {
        originalFormData = {};
        
        $('#tab-webhook input, #tab-webhook textarea, #tab-webhook select, #tab-form input:not(#smartcontact-form input), #tab-form textarea:not(#smartcontact-form textarea), #tab-form select:not(#smartcontact-form select)').each(function() {
            var $el = $(this);
            var name = $el.attr('name');
            if (name) {
                if ($el.attr('type') === 'checkbox') {
                    originalFormData[name] = $el.is(':checked');
                } else {
                    originalFormData[name] = $el.val();
                }
            }
        });
    }
    
    // Check if form has changed - only check webhook and form tabs
    function checkForChanges() {
        var hasChanged = false;
        
        $('#tab-webhook input, #tab-webhook textarea, #tab-webhook select, #tab-form input:not(#smartcontact-form input), #tab-form textarea:not(#smartcontact-form textarea), #tab-form select:not(#smartcontact-form select)').each(function() {
            var $el = $(this);
            var name = $el.attr('name');
            if (name && originalFormData.hasOwnProperty(name)) {
                var currentValue = $el.attr('type') === 'checkbox' ? $el.is(':checked') : $el.val();
                if (currentValue !== originalFormData[name]) {
                    hasChanged = true;
                    return false; // break the loop
                }
            }
        });
        
        hasUnsavedChanges = hasChanged;
        return hasChanged;
    }
    
    // Initialize form monitoring
    storeOriginalFormData();
    
    // Monitor form changes - only on webhook and form tabs, exclude preview form elements
    $(document).on('change input', '#tab-webhook input, #tab-webhook textarea, #tab-webhook select, #tab-form input:not(#smartcontact-form input), #tab-form textarea:not(#smartcontact-form textarea), #tab-form select:not(#smartcontact-form select)', function() {
        checkForChanges();
    });
    
    // Handle universal form submissions
    $(document).on('submit', 'form[action="options.php"]', function(e) {
        var activeTab = $('.nav-tab-active').data('tab');
        console.log('Universal save settings from tab:', activeTab);
        // Allow submission from webhook and form tabs only
        if (activeTab === 'webhook' || activeTab === 'form') {
            hasUnsavedChanges = false;
            window.onbeforeunload = null;
            console.log('Universal save settings allowed for tab:', activeTab);
            // Save all settings including webhook, form, popup, and custom fields
            // WordPress will handle the form submission automatically
        } else {
            e.preventDefault();
            console.log('Save settings blocked for tab:', activeTab);
            return false;
        }
    });
    
    // 2. Remove save button from preview and import/export tabs, and isolate save logic
    function toggleSaveButtons(activeTab) {
        // Show/hide save buttons based on active tab
        if (activeTab === 'webhook' || activeTab === 'form') {
            $('.smartcontact-save-buttons').show();
            $('.smartcontact-save-bottom').show();
        } else {
            $('.smartcontact-save-buttons').hide();
            $('.smartcontact-save-bottom').hide();
        }
        // Remove preview form and popup overlay when not on preview tab
        if (activeTab !== 'preview') {
            $('#smartcontact-form').remove();
            $('#smartcontact-popup-overlay').remove();
            $('.smartcontact-form-container').remove();
            $('[id*="smartcontact-"]').not('[id*="smartcontact-admin"]').not('[id*="smartcontact-settings"]').remove();
        }
    }
    
    // 3. Theme color conflict fix: Only set hasUnsavedChanges if the theme actually changes
    var currentTheme = $('#theme').val();
    $('.theme-preview-item').on('click', function() {
        var theme = $(this).data('theme');
        if (theme !== $('#theme').val()) {
            $('#theme').val(theme).trigger('change');
            $('.theme-preview-item').removeClass('active');
            $(this).addClass('active');
            hasUnsavedChanges = true;
        }
        // ONLY refresh preview if we're actually on the preview tab
        if ($('#tab-preview').is(':visible') && $('.nav-tab-active').data('tab') === 'preview') {
            refreshPreview();
        }
    });
    
    $('#theme').on('change', function() {
        var theme = $(this).val();
        $('.theme-preview-item').removeClass('active');
        $('.theme-preview-item[data-theme="' + theme + '"]').addClass('active');
        if (theme !== currentTheme) {
            hasUnsavedChanges = true;
            currentTheme = theme;
        }
        // ONLY refresh preview if we're actually on the preview tab
        if ($('#tab-preview').is(':visible') && $('.nav-tab-active').data('tab') === 'preview') {
            refreshPreview();
        }
    });
    
    // 4. Only show confirmation popup when navigating away with unsaved changes
    // Reduce 'Leaving Without Saving' warning: only show if real changes exist
    // Remove beforeunload handler entirely
    $(window).off('beforeunload');
    
    // Add CSS for spinning animation
    if (!$('#smartcontact-spin-css').length) {
        $('head').append('<style id="smartcontact-spin-css">@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } } .saving { opacity: 0.7; } .smartcontact-saving-indicator { animation: slideInRight 0.3s ease-out; } @keyframes slideInRight { from { transform: translateX(100%); } to { transform: translateX(0); } }</style>');
    }
    
    // Clear popup cookie for testing
    $('#clear-popup-cookie').on('click', function() {
        var $btn = $(this);
        var originalText = $btn.text();
        
        // Set cookie to expire in the past to delete it
        document.cookie = 'smartcontact_popup_shown=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
        
        // Visual feedback
        $btn.text('Cookie Cleared!').prop('disabled', true);
        
        setTimeout(function() {
            $btn.text(originalText).prop('disabled', false);
        }, 2000);
        
        alert('Popup cookie cleared! The popup should now show on your next visit to the frontend.');
    });
    
    // Save popup settings separately
    $('#save-popup-settings').on('click', function() {
        var $btn = $(this);
        var originalText = $btn.text();
        var $result = $('#popup-settings-result');
        
        // Collect popup settings
        var popupSettings = {
            popup_enabled: $('#popup_enabled').is(':checked') ? 1 : 0,
            popup_delay: $('#popup_delay').val(),
            popup_session_delay: $('#popup_session_delay').val(),
            session_popup_enabled: $('#session_popup_enabled').is(':checked') ? 1 : 0,
            session_popup_time: $('#session_popup_time').val()
        };
        
        // Show saving state
        $btn.html('<span class="dashicons dashicons-update" style="animation: spin 1s linear infinite; margin-right: 5px;"></span>Saving...').prop('disabled', true);
        $result.hide();
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'smartcontact_save_popup_settings',
                nonce: smartcontact_admin.nonce,
                popup_settings: popupSettings
            },
            success: function(response) {
                if (response.success) {
                    $result.removeClass('error').addClass('success').html('✅ ' + response.data).fadeIn();
                } else {
                    $result.removeClass('success').addClass('error').html('❌ ' + (response.data || 'Failed to save popup settings.')).fadeIn();
                }
                $btn.text(originalText).prop('disabled', false);
            },
            error: function() {
                $result.removeClass('success').addClass('error').html('❌ Error: Failed to connect to server.').fadeIn();
                $btn.text(originalText).prop('disabled', false);
            }
        });
    });
    

});
