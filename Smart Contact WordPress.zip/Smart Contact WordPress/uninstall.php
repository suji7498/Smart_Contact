<?php
/**
 * SmartContact Webhook Form Uninstall Script
 * 
 * This file is executed when the plugin is deleted (not just deactivated).
 * It respects the user's data deletion preferences.
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Define plugin constants (needed for file paths)
define('SMARTCONTACT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SMARTCONTACT_SUBMISSIONS_FILE', SMARTCONTACT_PLUGIN_DIR . 'data/submissions.json');

// Get plugin settings to check user's preference
$options = get_option('smartcontact_settings', array());
$delete_data = $options['delete_data_on_uninstall'] ?? '0';

// Only delete data if user explicitly chose to do so
if ($delete_data === '1') {
    // Delete submissions data file
    if (file_exists(SMARTCONTACT_SUBMISSIONS_FILE)) {
        unlink(SMARTCONTACT_SUBMISSIONS_FILE);
    }
    
    // Delete data directory if empty
    $data_dir = dirname(SMARTCONTACT_SUBMISSIONS_FILE);
    if (is_dir($data_dir)) {
        // Only delete if directory is empty (just in case there are other files)
        $files = array_diff(scandir($data_dir), array('.', '..', '.htaccess'));
        if (empty($files)) {
            rmdir($data_dir);
        }
    }
    
    // Delete plugin options from database
    delete_option('smartcontact_settings');
    
    // Clean up any other plugin-related data
    delete_transient('smartcontact_webhook_test');
    
    // Remove any scheduled events (if any were added in future)
    wp_clear_scheduled_hook('smartcontact_cleanup');
    
} else {
    // User chose to keep data - only remove plugin settings but keep submissions
    // We'll keep the submissions data file intact
    
    // Only delete the main settings, but keep a note that data exists
    $preservation_note = array(
        'data_preserved' => true,
        'preservation_date' => current_time('mysql'),
        'submissions_file' => SMARTCONTACT_SUBMISSIONS_FILE,
        'note' => 'Form submission data was preserved as requested by user settings.'
    );
    
    // Update options instead of deleting them completely
    update_option('smartcontact_data_preservation', $preservation_note);
    
    // Remove main settings but keep preservation record
    delete_option('smartcontact_settings');
}

// Create a log file for transparency about what was done
$log_file = SMARTCONTACT_PLUGIN_DIR . 'uninstall.log';
$log_message = date('Y-m-d H:i:s') . " - Plugin uninstalled.\n";
$log_message .= "Data deletion setting: " . ($delete_data === '1' ? 'DELETE' : 'PRESERVE') . "\n";
$log_message .= "Action taken: " . ($delete_data === '1' ? 'All data deleted' : 'Data preserved') . "\n";
$log_message .= "Submissions file: " . SMARTCONTACT_SUBMISSIONS_FILE . "\n";
$log_message .= "File exists: " . (file_exists(SMARTCONTACT_SUBMISSIONS_FILE) ? 'Yes' : 'No') . "\n\n";

file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX);